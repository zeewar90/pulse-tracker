package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.SampleHabits
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("PulseTrack", appName)
  }

  @Test
  fun `sample habits are populated`() {
    val sample = SampleHabits.initialHabits
    assertEquals(5, sample.size)
    assertTrue(sample.any { it.name == "Drink water" })
  }

  @Test
  fun `gemini coach roles are properly configured`() {
    val roles = com.example.data.gemini.CoachRole.values()
    assertEquals(3, roles.size)
    assertEquals("gemini-3.5-flash", com.example.data.gemini.CoachRole.DAILY_COACH.modelId)
    assertEquals("gemini-3.1-pro-preview", com.example.data.gemini.CoachRole.DEEP_STRATEGIST.modelId)
    assertEquals("gemini-3.1-flash-lite", com.example.data.gemini.CoachRole.QUICK_PEPTALK.modelId)
  }

  @Test
  fun `navigation screen routes are properly configured`() {
    assertEquals("today", com.example.ui.navigation.Screen.Today.route)
    assertEquals("habits", com.example.ui.navigation.Screen.Habits.route)
    assertEquals("add", com.example.ui.navigation.Screen.AddHabit.route)
    assertEquals("stats", com.example.ui.navigation.Screen.Stats.route)
    assertEquals("settings", com.example.ui.navigation.Screen.Settings.route)
    assertEquals("coach", com.example.ui.navigation.Screen.Coach.route)
    assertEquals("vision", com.example.ui.navigation.Screen.Vision.route)
    assertEquals("voice", com.example.ui.navigation.Screen.LiveVoice.route)
  }

  @Test
  fun `gemini live api model is configured for gemini-3_8-live`() {
    assertEquals("gemini-3.8-live", com.example.data.gemini.LiveSessionManager.LIVE_MODEL_NAME)
  }

  @Test
  fun `room database initializes with Habit, HabitCompletion, and Streak entities`() = kotlinx.coroutines.runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val db = androidx.room.Room.inMemoryDatabaseBuilder(
      context,
      com.example.data.PulseTrackDatabase::class.java
    ).allowMainThreadQueries().build()

    val habitDao = db.habitDao()
    val completionDao = db.habitCompletionDao()
    val streakDao = db.streakDao()

    // 1. Test Habit insertion
    val habit = com.example.data.Habit(
      id = 10,
      name = "Daily Reading",
      iconName = "book",
      frequency = "Daily",
      dailyGoal = 1,
      streak = 3,
      completedToday = true
    )
    val habitId = habitDao.insertHabit(habit)
    assertEquals(10L, habitId)

    val fetchedHabit = habitDao.getHabitById(10)
    assertEquals("Daily Reading", fetchedHabit?.name)

    // 2. Test HabitCompletion insertion
    val completion = com.example.data.HabitCompletion(
      habitId = 10,
      completionDate = "2026-09-24",
      count = 1,
      notes = "Finished chapter 4"
    )
    val completionId = completionDao.insertCompletion(completion)
    assertTrue(completionId > 0)

    val fetchedCompletion = completionDao.getCompletionForHabitAndDate(10, "2026-09-24")
    assertEquals("Finished chapter 4", fetchedCompletion?.notes)

    // 3. Test Streak insertion
    val streak = com.example.data.Streak(
      habitId = 10,
      currentStreak = 3,
      bestStreak = 7,
      lastCompletedDate = "2026-09-24"
    )
    val streakId = streakDao.insertStreak(streak)
    assertTrue(streakId > 0)

    val fetchedStreak = streakDao.getStreakForHabitSync(10)
    assertEquals(3, fetchedStreak?.currentStreak)
    assertEquals(7, fetchedStreak?.bestStreak)

    db.close()
  }

  @Test
  fun `HabitViewModel calculates streaks correctly on completion toggle`() {
    val app = ApplicationProvider.getApplicationContext<android.app.Application>()
    val viewModel = com.example.ui.HabitViewModel(app)

    // Test calculateStreak: incrementing when completed
    val (newStreak, newBest) = viewModel.calculateStreak(currentStreak = 4, bestStreak = 5, nowCompleted = true)
    assertEquals(5, newStreak)
    assertEquals(5, newBest)

    // Test calculateStreak: surpassing best streak
    val (newStreak2, newBest2) = viewModel.calculateStreak(currentStreak = 5, bestStreak = 5, nowCompleted = true)
    assertEquals(6, newStreak2)
    assertEquals(6, newBest2)

    // Test calculateStreak: decrementing when toggled off
    val (decrementStreak, unchangedBest) = viewModel.calculateStreak(currentStreak = 3, bestStreak = 7, nowCompleted = false)
    assertEquals(2, decrementStreak)
    assertEquals(7, unchangedBest)

    // Test calculateStreakFromHistory: consecutive 1s ending today
    val historyConsecutive3 = "0,1,0,0,1,1,1"
    val streak3 = viewModel.calculateStreakFromHistory(historyConsecutive3)
    assertEquals(3, streak3)

    val historyAll7 = "1,1,1,1,1,1,1"
    assertEquals(7, viewModel.calculateStreakFromHistory(historyAll7))

    val historyZeroToday = "1,1,1,1,1,1,0"
    assertEquals(0, viewModel.calculateStreakFromHistory(historyZeroToday))
  }
}
