package com.example.ui.pages

import android.graphics.Bitmap
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.gemini.GeminiClient
import com.example.data.gemini.VisionImageItem
import com.example.ui.HabitViewModel
import com.example.ui.theme.PulseAccent
import com.example.ui.theme.PulseBg
import com.example.ui.theme.PulseBorder
import com.example.ui.theme.PulseDestructive
import com.example.ui.theme.PulseInk
import com.example.ui.theme.PulseLightAmber
import com.example.ui.theme.PulseLightTeal
import com.example.ui.theme.PulseMuted
import com.example.ui.theme.PulseOnAccent
import com.example.ui.theme.PulsePrimary
import com.example.ui.theme.PulseSoft
import com.example.ui.theme.PulseSurface
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun VisionStudioScreen(
  viewModel: HabitViewModel,
  modifier: Modifier = Modifier,
  onNavigateBack: (() -> Unit)? = null
) {
  val visionImages by viewModel.visionImages.collectAsState()
  val isLoading by viewModel.isVisionLoading.collectAsState()
  val errorMessage by viewModel.visionError.collectAsState()
  val selectedForEdit by viewModel.selectedVisionForEdit.collectAsState()

  var selectedTabIndex by remember { mutableIntStateOf(0) } // 0: Create, 1: Edit
  var createPrompt by remember { mutableStateOf("") }
  var editPrompt by remember { mutableStateOf("") }
  var selectedAspectRatio by remember { mutableStateOf("1:1") }

  val aspectRatios = listOf("1:1", "16:9", "4:3", "9:16")

  val sampleVisionPrompts = listOf(
    "Peaceful sunrise yoga in a Scandinavian loft, soft morning mist, minimal aesthetic",
    "Crystal clear glass of fresh water with mint leaves, warm morning light, crisp photography",
    "Cozy reading armchair beside a rain-streaked window, warm tea cup with steam, calm mood",
    "Serene botanical forest path at dawn for a mindful morning walk, soft sunbeams"
  )

  val sampleEditPrompts = listOf(
    "Add a warm golden hour sunset glow and delicate watercolor splashes",
    "Transform into a futuristic neon vaporwave aesthetic with soft violet tones",
    "Add celebration confetti, motivational sparkles, and vibrant lighting",
    "Make the background a misty alpine mountain landscape"
  )

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(PulseBg)
  ) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .testTag("vision_studio_list"),
      contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 96.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // Header
      item {
        Column {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(
              modifier = Modifier.weight(1f, fill = false),
              verticalAlignment = Alignment.CenterVertically
            ) {
              if (onNavigateBack != null) {
                IconButton(
                  onClick = onNavigateBack,
                  modifier = Modifier
                    .size(36.dp)
                    .testTag("vision_back_button")
                ) {
                  Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back to previous screen",
                    tint = PulseInk,
                    modifier = Modifier.size(22.dp)
                  )
                }
                Spacer(modifier = Modifier.width(6.dp))
              }

              Column {
                Text(
                  text = "Habit Vision Board",
                  fontSize = 28.sp,
                  fontWeight = FontWeight.Bold,
                  color = PulseInk,
                  letterSpacing = (-0.5).sp
                )
                Text(
                  text = "Create & edit habit imagery with gemini-3.1-flash-image-preview",
                  fontSize = 13.sp,
                  color = PulseMuted,
                  modifier = Modifier.padding(top = 2.dp)
                )
              }
            }

            Box(
              modifier = Modifier
                .background(PulseLightAmber, RoundedCornerShape(8.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Text(
                text = "3.1-flash-image",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = PulseAccent
              )
            }
          }
        }
      }

      // Hero Vision Inspiration Card
      item {
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .height(130.dp),
          shape = RoundedCornerShape(12.dp),
          border = BorderStroke(1.dp, PulseBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Box(modifier = Modifier.fillMaxSize()) {
            Image(
              painter = painterResource(id = R.drawable.img_vision_hero),
              contentDescription = "Vision Inspiration",
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxSize()
            )
            Box(
              modifier = Modifier
                .fillMaxSize()
                .background(
                  Brush.verticalGradient(
                    colors = listOf(Color.Transparent, Color(0x991E2A27))
                  )
                )
            )
            Column(
              modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(14.dp)
            ) {
              Text(
                text = "Manifest Your Habits",
                color = PulseOnAccent,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = "Generate and transform high-clarity imagery for your daily intentions",
                color = PulseOnAccent.copy(alpha = 0.85f),
                fontSize = 11.sp
              )
            }
          }
        }
      }

      // Mode Selector Tabs (Create vs Edit)
      item {
        TabRow(
          selectedTabIndex = selectedTabIndex,
          containerColor = PulseSurface,
          contentColor = PulsePrimary,
          indicator = { tabPositions ->
            TabRowDefaults.SecondaryIndicator(
              modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
              color = PulseAccent,
              height = 3.dp
            )
          },
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, PulseBorder, RoundedCornerShape(12.dp))
        ) {
          Tab(
            selected = selectedTabIndex == 0,
            onClick = { selectedTabIndex = 0 },
            text = {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Create Image", fontWeight = FontWeight.SemiBold)
              }
            },
            selectedContentColor = PulseAccent,
            unselectedContentColor = PulseMuted
          )

          Tab(
            selected = selectedTabIndex == 1,
            onClick = { selectedTabIndex = 1 },
            text = {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Edit Image", fontWeight = FontWeight.SemiBold)
              }
            },
            selectedContentColor = PulseAccent,
            unselectedContentColor = PulseMuted
          )
        }
      }

      // Tab 0: Create Image
      if (selectedTabIndex == 0) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = PulseSurface),
            border = BorderStroke(1.dp, PulseBorder)
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
              verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
              Text(
                text = "Visual Habit Prompt",
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = PulseInk
              )

              OutlinedTextField(
                value = createPrompt,
                onValueChange = { createPrompt = it },
                placeholder = {
                  Text(
                    "Describe your ideal habit visual, e.g. 'A calm desk with a notebook and steaming green tea at dawn'...",
                    fontSize = 13.sp,
                    color = PulseMuted
                  )
                },
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                  focusedContainerColor = PulseSoft,
                  unfocusedContainerColor = PulseSoft,
                  focusedBorderColor = PulsePrimary,
                  unfocusedBorderColor = PulseBorder,
                  focusedTextColor = PulseInk,
                  unfocusedTextColor = PulseInk
                ),
                modifier = Modifier
                  .fillMaxWidth()
                  .height(100.dp)
                  .testTag("create_image_prompt_input")
              )

              // Aspect ratio chips
              Column {
                Text(
                  text = "Aspect Ratio",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Medium,
                  color = PulseMuted,
                  modifier = Modifier.padding(bottom = 6.dp)
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  aspectRatios.forEach { ratio ->
                    val isSelected = selectedAspectRatio == ratio
                    Surface(
                      shape = RoundedCornerShape(8.dp),
                      color = if (isSelected) PulsePrimary else PulseSoft,
                      border = BorderStroke(1.dp, if (isSelected) PulsePrimary else PulseBorder),
                      modifier = Modifier
                        .clickable { selectedAspectRatio = ratio }
                        .testTag("ratio_chip_$ratio")
                    ) {
                      Text(
                        text = ratio,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) PulseOnAccent else PulseInk,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                      )
                    }
                  }
                }
              }

              // Inspiration prompt chips
              Column {
                Text(
                  text = "Inspiration Prompts",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Medium,
                  color = PulseMuted,
                  modifier = Modifier.padding(bottom = 6.dp)
                )

                sampleVisionPrompts.forEach { sample ->
                  Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = PulseSoft,
                    border = BorderStroke(1.dp, PulseBorder),
                    modifier = Modifier
                      .fillMaxWidth()
                      .padding(vertical = 3.dp)
                      .clickable { createPrompt = sample }
                  ) {
                    Text(
                      text = sample,
                      fontSize = 11.sp,
                      color = PulseInk,
                      modifier = Modifier.padding(8.dp),
                      maxLines = 2
                    )
                  }
                }
              }

              Button(
                onClick = {
                  viewModel.generateVisionImage(createPrompt, selectedAspectRatio)
                },
                enabled = createPrompt.isNotBlank() && !isLoading,
                colors = ButtonDefaults.buttonColors(
                  containerColor = PulseAccent,
                  contentColor = PulseOnAccent
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                  .fillMaxWidth()
                  .height(48.dp)
                  .testTag("generate_image_button")
              ) {
                if (isLoading) {
                  CircularProgressIndicator(modifier = Modifier.size(18.dp), color = PulseOnAccent, strokeWidth = 2.dp)
                  Spacer(modifier = Modifier.width(8.dp))
                  Text("Generating with gemini-3.1-flash-image-preview...")
                } else {
                  Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                  Spacer(modifier = Modifier.width(8.dp))
                  Text("Generate Habit Vision Art", fontWeight = FontWeight.SemiBold)
                }
              }
            }
          }
        }
      }

      // Tab 1: Edit Image
      if (selectedTabIndex == 1) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = PulseSurface),
            border = BorderStroke(1.dp, PulseBorder)
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
              verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
              Text(
                text = "Edit Existing Vision Image",
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = PulseInk
              )

              if (selectedForEdit != null) {
                // Show selected image preview
                val originalBitmap = remember(selectedForEdit!!.base64Data) {
                  GeminiClient.base64ToBitmap(selectedForEdit!!.base64Data)
                }

                Box(
                  modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(PulseSoft)
                    .border(1.dp, PulsePrimary, RoundedCornerShape(10.dp)),
                  contentAlignment = Alignment.Center
                ) {
                  if (originalBitmap != null) {
                    Image(
                      bitmap = originalBitmap.asImageBitmap(),
                      contentDescription = selectedForEdit!!.prompt,
                      contentScale = ContentScale.Crop,
                      modifier = Modifier.fillMaxSize()
                    )
                  }

                  // Clear selection icon
                  IconButton(
                    onClick = { viewModel.selectVisionForEdit(null) },
                    modifier = Modifier
                      .align(Alignment.TopEnd)
                      .padding(8.dp)
                      .background(PulseSurface.copy(alpha = 0.8f), CircleShape)
                      .size(32.dp)
                  ) {
                    Icon(Icons.Default.Close, contentDescription = "Clear", tint = PulseInk, modifier = Modifier.size(16.dp))
                  }
                }

                Text(
                  text = "Original: \"${selectedForEdit!!.prompt}\"",
                  fontSize = 12.sp,
                  color = PulseMuted,
                  maxLines = 2
                )
              } else {
                // Prompt user to select an image from gallery
                Box(
                  modifier = Modifier
                    .fillMaxWidth()
                    .background(PulseSoft, RoundedCornerShape(10.dp))
                    .border(1.dp, PulseBorder, RoundedCornerShape(10.dp))
                    .padding(24.dp),
                  contentAlignment = Alignment.Center
                ) {
                  Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Image, contentDescription = null, tint = PulseMuted, modifier = Modifier.size(36.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                      text = if (visionImages.isEmpty()) "Generate an image first to edit it" else "Select an image from the gallery below to edit",
                      fontSize = 13.sp,
                      color = PulseMuted
                    )
                  }
                }
              }

              OutlinedTextField(
                value = editPrompt,
                onValueChange = { editPrompt = it },
                placeholder = {
                  Text(
                    "Describe the changes or edits, e.g. 'Add golden sunset lighting and soft watercolor brush strokes'...",
                    fontSize = 13.sp,
                    color = PulseMuted
                  )
                },
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                  focusedContainerColor = PulseSoft,
                  unfocusedContainerColor = PulseSoft,
                  focusedBorderColor = PulsePrimary,
                  unfocusedBorderColor = PulseBorder,
                  focusedTextColor = PulseInk,
                  unfocusedTextColor = PulseInk
                ),
                modifier = Modifier
                  .fillMaxWidth()
                  .height(100.dp)
                  .testTag("edit_image_prompt_input"),
                enabled = selectedForEdit != null
              )

              // Edit ideas
              if (selectedForEdit != null) {
                Column {
                  Text(
                    text = "Edit Ideas",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = PulseMuted,
                    modifier = Modifier.padding(bottom = 6.dp)
                  )

                  sampleEditPrompts.forEach { editSample ->
                    Surface(
                      shape = RoundedCornerShape(8.dp),
                      color = PulseSoft,
                      border = BorderStroke(1.dp, PulseBorder),
                      modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .clickable { editPrompt = editSample }
                    ) {
                      Text(
                        text = editSample,
                        fontSize = 11.sp,
                        color = PulseInk,
                        modifier = Modifier.padding(8.dp)
                      )
                    }
                  }
                }
              }

              Button(
                onClick = {
                  selectedForEdit?.let {
                    viewModel.editVisionImage(it, editPrompt, selectedAspectRatio)
                  }
                },
                enabled = selectedForEdit != null && editPrompt.isNotBlank() && !isLoading,
                colors = ButtonDefaults.buttonColors(
                  containerColor = PulseAccent,
                  contentColor = PulseOnAccent
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                  .fillMaxWidth()
                  .height(48.dp)
                  .testTag("apply_edit_button")
              ) {
                if (isLoading) {
                  CircularProgressIndicator(modifier = Modifier.size(18.dp), color = PulseOnAccent, strokeWidth = 2.dp)
                  Spacer(modifier = Modifier.width(8.dp))
                  Text("Transforming image with gemini-3.1-flash-image-preview...")
                } else {
                  Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(18.dp))
                  Spacer(modifier = Modifier.width(8.dp))
                  Text("Apply Image Edit", fontWeight = FontWeight.SemiBold)
                }
              }
            }
          }
        }
      }

      // Error banner
      if (errorMessage != null) {
        item {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .background(PulseLightAmber, RoundedCornerShape(10.dp))
              .border(1.dp, PulseBorder, RoundedCornerShape(10.dp))
              .padding(12.dp)
          ) {
            Column {
              Text(
                text = "Generation Notice",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = PulseAccent
              )
              Text(
                text = errorMessage!!,
                fontSize = 12.sp,
                color = PulseInk,
                modifier = Modifier.padding(top = 2.dp)
              )
            }
          }
        }
      }

      // Gallery Section
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Vision Gallery (${visionImages.size})",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = PulseInk
          )

          if (visionImages.isNotEmpty()) {
            Text(
              text = "Tap to edit with AI",
              fontSize = 12.sp,
              color = PulsePrimary,
              fontWeight = FontWeight.Medium
            )
          }
        }
      }

      if (visionImages.isEmpty()) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = PulseSurface),
            border = BorderStroke(1.dp, PulseBorder)
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = PulseAccent,
                modifier = Modifier.size(40.dp)
              )
              Spacer(modifier = Modifier.height(10.dp))
              Text(
                text = "No vision imagery generated yet",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = PulseInk
              )
              Text(
                text = "Use text prompts above to visualize your daily habits and goals with gemini-3.1-flash-image-preview.",
                fontSize = 12.sp,
                color = PulseMuted,
                modifier = Modifier.padding(top = 4.dp)
              )
            }
          }
        }
      } else {
        items(visionImages, key = { it.id }) { item ->
          VisionCard(
            item = item,
            onSelectForEdit = {
              viewModel.selectVisionForEdit(item)
              selectedTabIndex = 1
            },
            onDelete = {
              viewModel.deleteVisionImage(item.id)
            }
          )
        }
      }
    }
  }
}

@Composable
private fun VisionCard(
  item: VisionImageItem,
  onSelectForEdit: () -> Unit,
  onDelete: () -> Unit,
  modifier: Modifier = Modifier
) {
  val bitmap = remember(item.base64Data) {
    GeminiClient.base64ToBitmap(item.base64Data)
  }

  val dateStr = remember(item.timestamp) {
    SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()).format(Date(item.timestamp))
  }

  Card(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = PulseSurface),
    border = BorderStroke(1.dp, PulseBorder),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
  ) {
    Column(modifier = Modifier.fillMaxWidth()) {
      // Image Display
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(240.dp)
          .background(PulseSoft)
      ) {
        if (bitmap != null) {
          Image(
            bitmap = bitmap.asImageBitmap(),
            contentDescription = item.prompt,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
          )
        } else {
          Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Image, contentDescription = null, tint = PulseMuted, modifier = Modifier.size(48.dp))
          }
        }

        // Tags top row
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(10.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .background(PulseSurface.copy(alpha = 0.9f), RoundedCornerShape(6.dp))
              .padding(horizontal = 8.dp, vertical = 4.dp)
          ) {
            Text(
              text = if (item.isEdited) "Edited with AI" else "Created with AI",
              fontSize = 11.sp,
              fontWeight = FontWeight.SemiBold,
              color = if (item.isEdited) PulseAccent else PulsePrimary
            )
          }

          Box(
            modifier = Modifier
              .background(PulseSurface.copy(alpha = 0.9f), RoundedCornerShape(6.dp))
              .padding(horizontal = 8.dp, vertical = 4.dp)
          ) {
            Text(
              text = item.aspectRatio,
              fontSize = 11.sp,
              fontWeight = FontWeight.Medium,
              color = PulseInk
            )
          }
        }
      }

      // Details & Actions
      Column(modifier = Modifier.padding(16.dp)) {
        Text(
          text = item.prompt,
          fontSize = 14.sp,
          fontWeight = FontWeight.SemiBold,
          color = PulseInk,
          lineHeight = 20.sp
        )

        if (item.originalPrompt != null) {
          Text(
            text = "Original prompt: ${item.originalPrompt}",
            fontSize = 11.sp,
            color = PulseMuted,
            modifier = Modifier.padding(top = 2.dp)
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = dateStr,
            fontSize = 11.sp,
            color = PulseMuted
          )

          Row(verticalAlignment = Alignment.CenterVertically) {
            Button(
              onClick = onSelectForEdit,
              colors = ButtonDefaults.buttonColors(
                containerColor = PulseLightTeal,
                contentColor = PulsePrimary
              ),
              shape = RoundedCornerShape(8.dp),
              contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
            ) {
              Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Edit with AI", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }

            Spacer(modifier = Modifier.width(6.dp))

            IconButton(
              onClick = onDelete,
              modifier = Modifier.size(36.dp)
            ) {
              Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = PulseMuted, modifier = Modifier.size(18.dp))
            }
          }
        }
      }
    }
  }
}
