package com.example.ui.pages

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.HabitEntity
import com.example.ui.HabitViewModel
import com.example.ui.components.HabitIconBadge
import com.example.ui.components.PulseProgressBar
import com.example.ui.components.StatRing
import com.example.ui.theme.PulseAccent
import com.example.ui.theme.PulseBg
import com.example.ui.theme.PulseBorder
import com.example.ui.theme.PulseInk
import com.example.ui.theme.PulseLightAmber
import com.example.ui.theme.PulseLightTeal
import com.example.ui.theme.PulseMuted
import com.example.ui.theme.PulsePrimary
import com.example.ui.theme.PulseSoft
import com.example.ui.theme.PulseSurface

@Composable
fun StatsScreen(
  habits: List<HabitEntity>,
  viewModel: HabitViewModel,
  modifier: Modifier = Modifier
) {
  val stats = viewModel.calculateStats(habits)

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(PulseBg)
  ) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .testTag("stats_screen_list"),
      contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 96.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // Title
      item {
        Column {
          Text(
            text = "Analytics & Stats",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = PulseInk,
            letterSpacing = (-0.5).sp
          )
          Text(
            text = "Your consistency and momentum overview",
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            color = PulseMuted,
            modifier = Modifier.padding(top = 2.dp)
          )
        }
      }

      // Best Streak & Ring Summary Card
      item {
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .testTag("weekly_summary_card"),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = PulseSurface),
          border = BorderStroke(1.dp, PulseBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            // Stat Ring
            StatRing(
              percentage = stats.weeklyOverallPercent,
              size = 120.dp,
              strokeWidth = 10.dp,
              ringColor = PulsePrimary,
              trackColor = PulseSoft,
              centerLabel = "Weekly Avg"
            )

            Spacer(modifier = Modifier.width(16.dp))

            // Highlight Cards on the Right
            Column(
              modifier = Modifier.weight(1f),
              verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              // Best Streak
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .background(PulseLightAmber, RoundedCornerShape(10.dp))
                  .padding(12.dp)
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(
                    imageVector = Icons.Default.LocalFireDepartment,
                    contentDescription = null,
                    tint = PulseAccent,
                    modifier = Modifier.size(24.dp)
                  )
                  Spacer(modifier = Modifier.width(10.dp))
                  Column {
                    Text(
                      text = "${stats.bestStreak} Days",
                      fontSize = 17.sp,
                      fontWeight = FontWeight.Bold,
                      color = PulseInk
                    )
                    Text(
                      text = "Best Streak",
                      fontSize = 12.sp,
                      color = PulseMuted
                    )
                  }
                }
              }

              // Total habits tracked
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .background(PulseSoft, RoundedCornerShape(10.dp))
                  .padding(12.dp)
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(
                    imageVector = Icons.Default.TrendingUp,
                    contentDescription = null,
                    tint = PulsePrimary,
                    modifier = Modifier.size(24.dp)
                  )
                  Spacer(modifier = Modifier.width(10.dp))
                  Column {
                    Text(
                      text = "${stats.totalHabits} Active",
                      fontSize = 17.sp,
                      fontWeight = FontWeight.Bold,
                      color = PulseInk
                    )
                    Text(
                      text = "Habits Tracked",
                      fontSize = 12.sp,
                      color = PulseMuted
                    )
                  }
                }
              }
            }
          }
        }
      }

      // Streak Milestone Trophy Card
      item {
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .testTag("streak_trophy_card"),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = PulseSurface),
          border = BorderStroke(1.dp, PulseBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Image(
              painter = painterResource(id = R.drawable.img_streak_trophy),
              contentDescription = "Streak Milestone Trophy",
              contentScale = ContentScale.Crop,
              modifier = Modifier
                .size(68.dp)
                .clip(RoundedCornerShape(10.dp))
                .border(1.dp, PulseBorder, RoundedCornerShape(10.dp))
            )
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = "Momentum Trophy",
                  fontSize = 15.sp,
                  fontWeight = FontWeight.Bold,
                  color = PulseInk
                )
                Spacer(modifier = Modifier.width(6.dp))
                Box(
                  modifier = Modifier
                    .background(PulseLightAmber, RoundedCornerShape(6.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                  Text(
                    text = "${stats.bestStreak}d Record",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = PulseAccent
                  )
                }
              }
              Text(
                text = if (stats.bestStreak >= 7) "Superb consistency! You've unlocked the 7-day milestone trophy." else "Keep going! Build up your daily streak to unlock higher milestone tiers.",
                fontSize = 12.sp,
                color = PulseMuted,
                lineHeight = 16.sp,
                modifier = Modifier.padding(top = 3.dp)
              )
            }
          }
        }
      }

      // 7-Day Mini Bar Chart
      item {
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .testTag("weekly_barchart_card"),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = PulseSurface),
          border = BorderStroke(1.dp, PulseBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp)
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "Last 7 Days Activity",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = PulseInk
              )
              Text(
                text = "Daily completion",
                fontSize = 12.sp,
                color = PulseMuted
              )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // 7 vertical mini bars
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .height(100.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.Bottom
            ) {
              stats.dayLabels.forEachIndexed { index, label ->
                val rate = stats.dayCompletionRates.getOrElse(index) { 0f }
                val isToday = index == 6

                Column(
                  horizontalAlignment = Alignment.CenterHorizontally,
                  modifier = Modifier.weight(1f)
                ) {
                  // Bar container
                  Box(
                    modifier = Modifier
                      .width(18.dp)
                      .height(72.dp)
                      .clip(RoundedCornerShape(6.dp))
                      .background(PulseSoft),
                    contentAlignment = Alignment.BottomCenter
                  ) {
                    Box(
                      modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight(rate.coerceIn(0.08f, 1f))
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isToday) PulseAccent else PulsePrimary)
                    )
                  }

                  Spacer(modifier = Modifier.height(6.dp))

                  Text(
                    text = label,
                    fontSize = 11.sp,
                    fontWeight = if (isToday) FontWeight.Bold else FontWeight.Medium,
                    color = if (isToday) PulsePrimary else PulseMuted
                  )
                }
              }
            }
          }
        }
      }

      // Habit Breakdown Header
      item {
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = "Habit Breakdown",
          fontSize = 18.sp,
          fontWeight = FontWeight.SemiBold,
          color = PulseInk
        )
      }

      // Per-Habit Weekly Progress Bars
      if (habits.isEmpty()) {
        item {
          Text(
            text = "No habit statistics available yet.",
            fontSize = 14.sp,
            color = PulseMuted,
            modifier = Modifier.padding(vertical = 12.dp)
          )
        }
      } else {
        items(habits, key = { "stat_${it.id}" }) { habit ->
          HabitStatRow(habit = habit)
        }
      }
    }
  }
}

@Composable
private fun HabitStatRow(
  habit: HabitEntity,
  modifier: Modifier = Modifier
) {
  val percent = (habit.getWeeklyCompletionPercent() * 100).toInt()

  Card(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = PulseSurface),
    border = BorderStroke(1.dp, PulseBorder),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          HabitIconBadge(
            iconName = habit.iconName,
            size = 38.dp,
            iconSize = 20.dp,
            backgroundColor = PulseLightTeal,
            iconTint = PulsePrimary
          )

          Spacer(modifier = Modifier.width(12.dp))

          Column {
            Text(
              text = habit.name,
              fontSize = 15.sp,
              fontWeight = FontWeight.SemiBold,
              color = PulseInk
            )
            Text(
              text = "${habit.frequency} • ${habit.dailyGoal}/day",
              fontSize = 12.sp,
              color = PulseMuted
            )
          }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .background(PulseLightAmber, RoundedCornerShape(4.dp))
              .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.LocalFireDepartment,
                contentDescription = null,
                tint = PulseAccent,
                modifier = Modifier.size(12.dp)
              )
              Spacer(modifier = Modifier.width(2.dp))
              Text(
                text = "${habit.streak}d",
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = PulseAccent
              )
            }
          }

          Spacer(modifier = Modifier.width(8.dp))

          Text(
            text = "$percent%",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = PulsePrimary
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      PulseProgressBar(
        progress = habit.getWeeklyCompletionPercent(),
        height = 6.dp,
        trackColor = PulseSoft,
        progressColor = PulsePrimary
      )
    }
  }
}
