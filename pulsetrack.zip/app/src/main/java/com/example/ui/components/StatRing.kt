package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.PulseInk
import com.example.ui.theme.PulseMuted
import com.example.ui.theme.PulsePrimary
import com.example.ui.theme.PulseSoft

@Composable
fun StatRing(
  percentage: Int,
  modifier: Modifier = Modifier,
  size: Dp = 140.dp,
  strokeWidth: Dp = 12.dp,
  ringColor: Color = PulsePrimary,
  trackColor: Color = PulseSoft,
  centerLabel: String = "This week"
) {
  val targetProgress = (percentage.coerceIn(0, 100) / 100f)
  val animatedProgress by animateFloatAsState(
    targetValue = targetProgress,
    animationSpec = tween(durationMillis = 600),
    label = "statRingProgress"
  )

  Box(
    modifier = modifier.size(size),
    contentAlignment = Alignment.Center
  ) {
    Canvas(modifier = Modifier.size(size)) {
      val strokePx = strokeWidth.toPx()
      val arcSize = size.toPx() - strokePx
      val topLeft = Offset(strokePx / 2f, strokePx / 2f)

      // Background track
      drawArc(
        color = trackColor,
        startAngle = -90f,
        sweepAngle = 360f,
        useCenter = false,
        topLeft = topLeft,
        size = Size(arcSize, arcSize),
        style = Stroke(width = strokePx, cap = StrokeCap.Round)
      )

      // Foreground animated progress
      if (animatedProgress > 0f) {
        drawArc(
          color = ringColor,
          startAngle = -90f,
          sweepAngle = 360f * animatedProgress,
          useCenter = false,
          topLeft = topLeft,
          size = Size(arcSize, arcSize),
          style = Stroke(width = strokePx, cap = StrokeCap.Round)
        )
      }
    }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      Text(
        text = "$percentage%",
        fontSize = 28.sp,
        fontWeight = FontWeight.Bold,
        color = PulseInk
      )
      Text(
        text = centerLabel,
        fontSize = 11.sp,
        fontWeight = FontWeight.Medium,
        color = PulseMuted
      )
    }
  }
}
