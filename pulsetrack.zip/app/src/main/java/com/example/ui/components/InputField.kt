package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.PulseBorder
import com.example.ui.theme.PulseDestructive
import com.example.ui.theme.PulseInk
import com.example.ui.theme.PulseMuted
import com.example.ui.theme.PulsePrimary
import com.example.ui.theme.PulseSurface

@Composable
fun PulseInputField(
  value: String,
  onValueChange: (String) -> Unit,
  label: String,
  modifier: Modifier = Modifier,
  placeholder: String = "",
  helperText: String? = null,
  errorMessage: String? = null,
  isError: Boolean = !errorMessage.isNullOrEmpty(),
  leadingIcon: @Composable (() -> Unit)? = null,
  trailingIcon: @Composable (() -> Unit)? = null,
  singleLine: Boolean = true,
  keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
  keyboardActions: KeyboardActions = KeyboardActions.Default,
  testTag: String = "input_field"
) {
  Column(modifier = modifier.fillMaxWidth()) {
    Text(
      text = label,
      fontSize = 13.sp,
      fontWeight = FontWeight.SemiBold,
      color = PulseInk,
      modifier = Modifier.padding(bottom = 6.dp)
    )

    OutlinedTextField(
      value = value,
      onValueChange = onValueChange,
      modifier = Modifier
        .fillMaxWidth()
        .testTag(testTag),
      placeholder = {
        if (placeholder.isNotEmpty()) {
          Text(
            text = placeholder,
            fontSize = 14.sp,
            color = PulseMuted
          )
        }
      },
      leadingIcon = leadingIcon,
      trailingIcon = trailingIcon,
      singleLine = singleLine,
      shape = RoundedCornerShape(10.dp),
      keyboardOptions = keyboardOptions,
      keyboardActions = keyboardActions,
      isError = isError,
      colors = OutlinedTextFieldDefaults.colors(
        focusedContainerColor = PulseSurface,
        unfocusedContainerColor = PulseSurface,
        focusedBorderColor = PulsePrimary,
        unfocusedBorderColor = PulseBorder,
        errorBorderColor = PulseDestructive,
        focusedTextColor = PulseInk,
        unfocusedTextColor = PulseInk,
        cursorColor = PulsePrimary
      )
    )

    if (isError && !errorMessage.isNullOrEmpty()) {
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = errorMessage,
        fontSize = 12.sp,
        color = PulseDestructive
      )
    } else if (!helperText.isNullOrEmpty()) {
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = helperText,
        fontSize = 12.sp,
        color = PulseMuted
      )
    }
  }
}
