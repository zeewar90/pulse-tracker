package com.example.ui.pages

import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Habit
import com.example.ui.FocusSessionRecord
import com.example.ui.HabitViewModel
import com.example.ui.components.HabitIcon
import com.example.ui.theme.PulseAccent
import com.example.ui.theme.PulseBg
import com.example.ui.theme.PulseBorder
import com.example.ui.theme.PulseInk
import com.example.ui.theme.PulseLightAmber
import com.example.ui.theme.PulseLightTeal
import com.example.ui.theme.PulseMuted
import com.example.ui.theme.PulseOnAccent
import com.example.ui.theme.PulsePrimary
import com.example.ui.theme.PulseSoft
import com.example.ui.theme.PulseSurface
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class TimerPreset(val label: String, val minutes: Int, val description: String) {
  POMODORO("Pomodoro", 25, "Standard productivity interval"),
  SPRINT("Quick Sprint", 15, "Fast burst of momentum"),
  DEEP_WORK("Deep Work", 45, "Uninterrupted flow state"),
  BREAK("Mindful Break", 5, "Rest and recharge")
}

@Composable
fun FocusTimerScreen(
  viewModel: HabitViewModel,
  onNavigateBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  val habits by viewModel.allHabits.collectAsState()
  val focusSessions by viewModel.focusSessions.collectAsState()
  val haptic = LocalHapticFeedback.current

  var selectedPreset by remember { mutableStateOf(TimerPreset.POMODORO) }
  var selectedHabit by remember { mutableStateOf<Habit?>(null) }
  var totalDurationSeconds by remember(selectedPreset) { mutableIntStateOf(selectedPreset.minutes * 60) }
  var remainingSeconds by remember(selectedPreset) { mutableIntStateOf(selectedPreset.minutes * 60) }
  var isRunning by remember { mutableStateOf(false) }
  var soundEnabled by remember { mutableStateOf(true) }
  var showCompletionDialog by remember { mutableStateOf(false) }

  // Set default habit when list loads
  LaunchedEffect(habits) {
    if (selectedHabit == null && habits.isNotEmpty()) {
      selectedHabit = habits.firstOrNull { !it.completedToday } ?: habits.firstOrNull()
    }
  }

  // Ticking countdown effect
  LaunchedEffect(isRunning, remainingSeconds) {
    if (isRunning && remainingSeconds > 0) {
      delay(1000L)
      remainingSeconds -= 1
    } else if (isRunning && remainingSeconds == 0) {
      isRunning = false
      haptic.performHapticFeedback(HapticFeedbackType.LongPress)
      if (soundEnabled) {
        try {
          val tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 90)
          tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 500)
        } catch (_: Exception) {}
      }
      viewModel.recordFocusSession(
        habit = selectedHabit,
        durationMinutes = totalDurationSeconds / 60
      )
      showCompletionDialog = true
    }
  }

  val progress = if (totalDurationSeconds > 0) {
    1f - (remainingSeconds.toFloat() / totalDurationSeconds.toFloat())
  } else 0f
  val animatedProgress by animateFloatAsState(targetValue = progress, label = "focus_progress")

  val minutes = remainingSeconds / 60
  val seconds = remainingSeconds % 60
  val formattedTime = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds)

  val totalTodayMinutes = remember(focusSessions) {
    focusSessions.sumOf { it.durationMinutes }
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(PulseBg)
  ) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .testTag("focus_timer_screen"),
      contentPadding = PaddingValues(horizontal = 16.dp, vertical = 20.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // Top Navigation Bar
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          IconButton(
            onClick = onNavigateBack,
            modifier = Modifier.testTag("focus_back_button")
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Back",
              tint = PulseInk
            )
          }
          Spacer(modifier = Modifier.width(8.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "Focus Studio",
              fontSize = 20.sp,
              fontWeight = FontWeight.Bold,
              color = PulseInk
            )
            Text(
              text = "Pomodoro & Deep Work Session",
              fontSize = 12.sp,
              color = PulseMuted
            )
          }

          IconButton(
            onClick = { soundEnabled = !soundEnabled },
            modifier = Modifier.testTag("focus_sound_toggle")
          ) {
            Icon(
              imageVector = if (soundEnabled) Icons.Default.NotificationsActive else Icons.Default.NotificationsOff,
              contentDescription = "Sound Toggle",
              tint = if (soundEnabled) PulsePrimary else PulseMuted
            )
          }
        }
      }

      // Habit Selection Row
      item {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(
            text = "Select Habit to Focus On",
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = PulseInk
          )

          LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(horizontal = 2.dp)
          ) {
            item {
              val isSelected = selectedHabit == null
              Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (isSelected) PulsePrimary else PulseSoft,
                border = BorderStroke(1.dp, if (isSelected) PulsePrimary else PulseBorder),
                modifier = Modifier
                  .clip(RoundedCornerShape(12.dp))
                  .clickable { selectedHabit = null }
                  .testTag("habit_chip_general")
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Icon(
                    imageVector = Icons.Default.Timer,
                    contentDescription = null,
                    tint = if (isSelected) PulseOnAccent else PulseInk,
                    modifier = Modifier.size(16.dp)
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = "General Focus",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (isSelected) PulseOnAccent else PulseInk
                  )
                }
              }
            }

            items(habits, key = { it.id }) { habit ->
              val isSelected = selectedHabit?.id == habit.id
              Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (isSelected) PulsePrimary else PulseSoft,
                border = BorderStroke(1.dp, if (isSelected) PulsePrimary else PulseBorder),
                modifier = Modifier
                  .clip(RoundedCornerShape(12.dp))
                  .clickable { selectedHabit = habit }
                  .testTag("habit_chip_${habit.id}")
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  HabitIcon(iconName = habit.iconName, tint = if (isSelected) PulseOnAccent else PulsePrimary, size = 16.dp)
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = habit.name,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (isSelected) PulseOnAccent else PulseInk
                  )
                  if (habit.completedToday) {
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                      imageVector = Icons.Default.CheckCircle,
                      contentDescription = "Completed",
                      tint = if (isSelected) PulseOnAccent else PulsePrimary,
                      modifier = Modifier.size(12.dp)
                    )
                  }
                }
              }
            }
          }
        }
      }

      // Interval Presets
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          TimerPreset.values().forEach { preset ->
            val isSelected = selectedPreset == preset
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = if (isSelected) PulseLightAmber else PulseSoft,
              border = BorderStroke(1.dp, if (isSelected) PulseAccent else PulseBorder),
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(10.dp))
                .clickable(enabled = !isRunning) {
                  selectedPreset = preset
                  totalDurationSeconds = preset.minutes * 60
                  remainingSeconds = preset.minutes * 60
                }
                .testTag("preset_${preset.name.lowercase()}")
            ) {
              Column(
                modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally
              ) {
                Text(
                  text = "${preset.minutes}m",
                  fontSize = 15.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (isSelected) PulseAccent else PulseInk
                )
                Text(
                  text = preset.label,
                  fontSize = 10.sp,
                  color = PulseMuted,
                  maxLines = 1
                )
              }
            }
          }
        }
      }

      // Circular Focus Clock Dial
      item {
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .testTag("focus_clock_card"),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = PulseSurface),
          border = BorderStroke(1.dp, PulseBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 28.dp, horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Box(
              modifier = Modifier.size(240.dp),
              contentAlignment = Alignment.Center
            ) {
              // Circular progress ring
              Canvas(modifier = Modifier.fillMaxSize()) {
                val strokeWidth = 14.dp.toPx()
                // Track
                drawCircle(
                  color = PulseSoft,
                  style = Stroke(width = strokeWidth)
                )
                // Progress Arc
                drawArc(
                  color = if (remainingSeconds > 0) PulsePrimary else PulseAccent,
                  startAngle = -90f,
                  sweepAngle = animatedProgress * 360f,
                  useCenter = false,
                  style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                )
              }

              // Center display
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                  text = formattedTime,
                  fontSize = 46.sp,
                  fontWeight = FontWeight.Bold,
                  fontFamily = FontFamily.Monospace,
                  color = PulseInk,
                  letterSpacing = (-1).sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Surface(
                  shape = RoundedCornerShape(12.dp),
                  color = when {
                    remainingSeconds == 0 -> PulseLightAmber
                    isRunning -> PulseLightTeal
                    else -> PulseSoft
                  }
                ) {
                  Text(
                    text = when {
                      remainingSeconds == 0 -> "Completed! 🎉"
                      isRunning -> "Deep in the Zone"
                      remainingSeconds < totalDurationSeconds -> "Paused"
                      else -> "Ready to Focus"
                    },
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = when {
                      remainingSeconds == 0 -> PulseAccent
                      isRunning -> PulsePrimary
                      else -> PulseMuted
                    },
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                  )
                }

                if (selectedHabit != null) {
                  Spacer(modifier = Modifier.height(6.dp))
                  Text(
                    text = selectedHabit!!.name,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = PulseMuted,
                    maxLines = 1
                  )
                }
              }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Play / Pause / Reset Control Buttons
            Row(
              horizontalArrangement = Arrangement.spacedBy(16.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              // Reset Button
              IconButton(
                onClick = {
                  isRunning = false
                  remainingSeconds = totalDurationSeconds
                },
                modifier = Modifier
                  .size(48.dp)
                  .background(PulseSoft, CircleShape)
                  .testTag("focus_reset_button")
              ) {
                Icon(
                  imageVector = Icons.Default.Refresh,
                  contentDescription = "Reset Timer",
                  tint = PulseInk
                )
              }

              // Big Main Toggle Button
              Button(
                onClick = {
                  isRunning = !isRunning
                  haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                },
                colors = ButtonDefaults.buttonColors(
                  containerColor = if (isRunning) PulseLightAmber else PulseAccent,
                  contentColor = if (isRunning) PulseAccent else PulseOnAccent
                ),
                shape = CircleShape,
                modifier = Modifier
                  .size(72.dp)
                  .testTag("focus_toggle_button")
              ) {
                Icon(
                  imageVector = if (isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                  contentDescription = if (isRunning) "Pause" else "Start",
                  modifier = Modifier.size(34.dp)
                )
              }

              // Fast Complete (Skip) Button for testing/flexibility
              IconButton(
                onClick = {
                  if (remainingSeconds > 0) {
                    remainingSeconds = 0
                  }
                },
                modifier = Modifier
                  .size(48.dp)
                  .background(PulseSoft, CircleShape)
                  .testTag("focus_fast_finish_button")
              ) {
                Icon(
                  imageVector = Icons.Default.CheckCircle,
                  contentDescription = "Finish Session",
                  tint = PulsePrimary
                )
              }
            }
          }
        }
      }

      // Today's Focus Stats Card
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = PulseSoft),
          border = BorderStroke(1.dp, PulseBorder)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceAround
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text(
                text = "${totalTodayMinutes}m",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = PulsePrimary
              )
              Text(
                text = "Focused Today",
                fontSize = 11.sp,
                color = PulseMuted
              )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text(
                text = "${focusSessions.size}",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = PulseAccent
              )
              Text(
                text = "Sessions Done",
                fontSize = 11.sp,
                color = PulseMuted
              )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              val completedHabitsCount = habits.count { it.completedToday }
              Text(
                text = "$completedHabitsCount / ${habits.size}",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = PulseInk
              )
              Text(
                text = "Habits Done",
                fontSize = 11.sp,
                color = PulseMuted
              )
            }
          }
        }
      }

      // Recent Focus Sessions List
      if (focusSessions.isNotEmpty()) {
        item {
          Text(
            text = "Today's Focus Log",
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            color = PulseInk
          )
        }

        items(focusSessions.take(5)) { session ->
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = PulseSurface),
            border = BorderStroke(1.dp, PulseBorder)
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(32.dp)
                    .background(PulseLightTeal, CircleShape),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(
                    imageVector = Icons.Default.Timer,
                    contentDescription = null,
                    tint = PulsePrimary,
                    modifier = Modifier.size(16.dp)
                  )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                  Text(
                    text = session.habitName,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = PulseInk
                  )
                  Text(
                    text = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(session.timestamp)),
                    fontSize = 11.sp,
                    color = PulseMuted
                  )
                }
              }

              Surface(
                shape = RoundedCornerShape(8.dp),
                color = PulseLightAmber
              ) {
                Text(
                  text = "+${session.durationMinutes} min",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = PulseAccent,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
              }
            }
          }
        }
      }
    }
  }

  // Completion Dialog
  if (showCompletionDialog) {
    AlertDialog(
      onDismissRequest = { showCompletionDialog = false },
      title = {
        Text(
          text = "Focus Session Complete! 🎉",
          fontWeight = FontWeight.Bold,
          color = PulseInk
        )
      },
      text = {
        Column {
          Text(
            text = "Great discipline! You completed a ${totalDurationSeconds / 60}-minute focus session on ${selectedHabit?.name ?: "General Focus"}.",
            fontSize = 14.sp,
            color = PulseInk
          )
          if (selectedHabit != null && !selectedHabit!!.completedToday) {
            Spacer(modifier = Modifier.height(12.dp))
            Text(
              text = "Would you like to mark '${selectedHabit!!.name}' as completed for today?",
              fontSize = 13.sp,
              fontWeight = FontWeight.Medium,
              color = PulsePrimary
            )
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (selectedHabit != null && !selectedHabit!!.completedToday) {
              viewModel.toggleHabitCompletion(selectedHabit!!)
            }
            showCompletionDialog = false
            remainingSeconds = totalDurationSeconds
          },
          colors = ButtonDefaults.buttonColors(
            containerColor = PulseAccent,
            contentColor = PulseOnAccent
          )
        ) {
          Text(if (selectedHabit != null && !selectedHabit!!.completedToday) "Mark Habit Done" else "Great!")
        }
      },
      dismissButton = {
        TextButton(
          onClick = {
            showCompletionDialog = false
            remainingSeconds = totalDurationSeconds
          }
        ) {
          Text("Close", color = PulseMuted)
        }
      },
      containerColor = PulseSurface
    )
  }
}
