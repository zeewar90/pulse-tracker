package com.example.ui.pages

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.gemini.ChatMessage
import com.example.data.gemini.CoachRole
import com.example.ui.HabitViewModel
import com.example.ui.theme.PulseAccent
import com.example.ui.theme.PulseBg
import com.example.ui.theme.PulseBorder
import com.example.ui.theme.PulseInk
import com.example.ui.theme.PulseLightAmber
import com.example.ui.theme.PulseLightTeal
import com.example.ui.theme.PulseMuted
import com.example.ui.theme.PulseOnAccent
import com.example.ui.theme.PulsePrimary
import com.example.ui.theme.PulseSoft
import com.example.ui.theme.PulseSurface
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ChatScreen(
  viewModel: HabitViewModel,
  modifier: Modifier = Modifier,
  onNavigateBack: (() -> Unit)? = null,
  onNavigateToLiveVoice: (() -> Unit)? = null
) {
  val messages by viewModel.chatMessages.collectAsState()
  val selectedRole by viewModel.selectedCoachRole.collectAsState()
  val isLoading by viewModel.isChatLoading.collectAsState()

  var inputText by remember { mutableStateOf("") }
  var showSystemInfo by remember { mutableStateOf(false) }

  val listState = rememberLazyListState()

  // Scroll to bottom when new messages arrive
  LaunchedEffect(messages.size, isLoading) {
    if (messages.isNotEmpty()) {
      listState.animateScrollToItem(messages.size - 1)
    }
  }

  val promptSuggestions = remember(selectedRole) {
    when (selectedRole) {
      CoachRole.DAILY_COACH -> listOf(
        "How do I stick to my morning routine?",
        "Tips to drink 8 glasses of water daily",
        "Celebrate my 5-day reading streak!",
        "Quick reminder on habit stacking"
      )
      CoachRole.DEEP_STRATEGIST -> listOf(
        "Why do I self-sabotage on day 4?",
        "Breakdown the psychological cue-routine-reward loop",
        "How to design an environment that prevents laziness?",
        "Overcoming cognitive fatigue after work"
      )
      CoachRole.QUICK_PEPTALK -> listOf(
        "Give me a 10-second push to workout!",
        "I want to procrastinate, stop me.",
        "Quick stretch reminder!",
        "One micro-action I can do right now"
      )
    }
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(PulseBg)
      .imePadding()
  ) {
    Column(
      modifier = Modifier.fillMaxSize()
    ) {
      // Top Bar: Coach Roles & Actions
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(PulseSurface)
          .padding(top = 16.dp, bottom = 12.dp, start = 16.dp, end = 16.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            if (onNavigateBack != null) {
              IconButton(
                onClick = onNavigateBack,
                modifier = Modifier
                  .size(36.dp)
                  .testTag("chat_back_button")
              ) {
                Icon(
                  imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                  contentDescription = "Back to previous screen",
                  tint = PulseInk,
                  modifier = Modifier.size(20.dp)
                )
              }
              Spacer(modifier = Modifier.width(6.dp))
            }

            Image(
              painter = painterResource(id = R.drawable.img_coach_banner),
              contentDescription = "Coach Pulse Avatar",
              contentScale = ContentScale.Crop,
              modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .border(1.dp, PulseBorder, CircleShape)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "Coach Pulse",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = PulseInk,
                letterSpacing = (-0.3).sp
              )
              Text(
                text = "AI Multi-Turn Habit Mentor",
                fontSize = 12.sp,
                color = PulseMuted
              )
            }
          }

          Row(verticalAlignment = Alignment.CenterVertically) {
            if (onNavigateToLiveVoice != null) {
              IconButton(
                onClick = onNavigateToLiveVoice,
                modifier = Modifier
                  .size(36.dp)
                  .testTag("start_live_voice_call_button")
              ) {
                Icon(
                  imageVector = Icons.Default.RecordVoiceOver,
                  contentDescription = "Start Live Voice Call with gemini-3.8-live",
                  tint = PulseAccent,
                  modifier = Modifier.size(22.dp)
                )
              }
              Spacer(modifier = Modifier.width(4.dp))
            }

            IconButton(
              onClick = { showSystemInfo = !showSystemInfo },
              modifier = Modifier.testTag("toggle_system_info_button")
            ) {
              Icon(
                imageVector = Icons.Default.Info,
                contentDescription = "System Role Info",
                tint = if (showSystemInfo) PulsePrimary else PulseMuted,
                modifier = Modifier.size(20.dp)
              )
            }

            IconButton(
              onClick = { viewModel.clearChat() },
              modifier = Modifier.testTag("clear_chat_button")
            ) {
              Icon(
                imageVector = Icons.Default.DeleteSweep,
                contentDescription = "Clear Chat",
                tint = PulseMuted,
                modifier = Modifier.size(20.dp)
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Role Selector Chips (gemini-3.5-flash, gemini-3.1-pro-preview, gemini-3.1-flash-lite)
        LazyRow(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          contentPadding = PaddingValues(horizontal = 2.dp)
        ) {
          items(CoachRole.values()) { role ->
            val isSelected = role == selectedRole
            Surface(
              shape = RoundedCornerShape(20.dp),
              color = if (isSelected) PulsePrimary else PulseSoft,
              border = BorderStroke(1.dp, if (isSelected) PulsePrimary else PulseBorder),
              modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .clickable { viewModel.selectCoachRole(role) }
                .testTag("role_chip_${role.name}")
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(
                  imageVector = when (role) {
                    CoachRole.DAILY_COACH -> Icons.Default.SmartToy
                    CoachRole.DEEP_STRATEGIST -> Icons.Default.Psychology
                    CoachRole.QUICK_PEPTALK -> Icons.Default.Bolt
                  },
                  contentDescription = null,
                  tint = if (isSelected) PulseOnAccent else PulseInk,
                  modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = role.title,
                  fontSize = 12.sp,
                  fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Medium,
                  color = if (isSelected) PulseOnAccent else PulseInk
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = "• ${role.modelId.substringAfter("gemini-")}",
                  fontSize = 10.sp,
                  color = if (isSelected) PulseOnAccent.copy(alpha = 0.8f) else PulseMuted
                )
              }
            }
          }
        }

        // Expandable System Instruction card
        if (showSystemInfo) {
          Spacer(modifier = Modifier.height(10.dp))
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .background(PulseSoft, RoundedCornerShape(10.dp))
              .border(1.dp, PulseBorder, RoundedCornerShape(10.dp))
              .padding(12.dp)
          ) {
            Column {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = "System Instruction (${selectedRole.modelId})",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  color = PulsePrimary
                )
                Text(
                  text = selectedRole.speedLabel,
                  fontSize = 11.sp,
                  color = PulseAccent,
                  fontWeight = FontWeight.SemiBold
                )
              }
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = selectedRole.systemInstruction,
                fontSize = 11.sp,
                lineHeight = 16.sp,
                color = PulseInk
              )
            }
          }
        }
      }

      // Message Thread
      LazyColumn(
        state = listState,
        modifier = Modifier
          .weight(1f)
          .fillMaxWidth()
          .testTag("chat_messages_list"),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        if (messages.isEmpty()) {
          item {
            Card(
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(12.dp),
              colors = CardDefaults.cardColors(containerColor = PulseSurface),
              border = BorderStroke(1.dp, PulseBorder)
            ) {
              Column(modifier = Modifier.fillMaxWidth()) {
                Image(
                  painter = painterResource(id = R.drawable.img_coach_banner),
                  contentDescription = "Coach Pulse Illustration",
                  contentScale = ContentScale.Crop,
                  modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                )
                Column(modifier = Modifier.padding(16.dp)) {
                  Text(
                    text = "Welcome to Coach Pulse",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = PulseInk
                  )
                  Text(
                    text = "I'm your AI habit mentor powered by ${selectedRole.modelId}. Ask me to troubleshoot broken streaks, construct frictionless morning routines, or give you a quick boost of motivation!",
                    fontSize = 13.sp,
                    color = PulseMuted,
                    lineHeight = 18.sp,
                    modifier = Modifier.padding(top = 4.dp)
                  )
                }
              }
            }
          }
        }

        items(messages, key = { it.id }) { msg ->
          ChatBubble(message = msg)
        }

        if (isLoading) {
          item {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier
                .background(PulseSurface, RoundedCornerShape(12.dp))
                .border(1.dp, PulseBorder, RoundedCornerShape(12.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
              CircularProgressIndicator(
                modifier = Modifier.size(16.dp),
                color = PulsePrimary,
                strokeWidth = 2.dp
              )
              Spacer(modifier = Modifier.width(10.dp))
              Text(
                text = "Coach is thinking (${selectedRole.modelId})...",
                fontSize = 13.sp,
                color = PulseMuted,
                fontWeight = FontWeight.Medium
              )
            }
          }
        }
      }

      // Quick Suggestion Chips
      LazyRow(
        modifier = Modifier
          .fillMaxWidth()
          .background(PulseBg)
          .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        items(promptSuggestions) { prompt ->
          Surface(
            shape = RoundedCornerShape(16.dp),
            color = PulseSurface,
            border = BorderStroke(1.dp, PulseBorder),
            modifier = Modifier
              .clip(RoundedCornerShape(16.dp))
              .clickable {
                inputText = prompt
                viewModel.sendChatMessage(prompt)
                inputText = ""
              }
          ) {
            Text(
              text = prompt,
              fontSize = 12.sp,
              color = PulseInk,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
            )
          }
        }
      }

      // Bottom Input Bar
      Surface(
        modifier = Modifier.fillMaxWidth(),
        color = PulseSurface,
        tonalElevation = 2.dp,
        border = BorderStroke(1.dp, PulseBorder)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          OutlinedTextField(
            value = inputText,
            onValueChange = { inputText = it },
            placeholder = { Text("Ask Coach Pulse about habits, streaks, mindset...", fontSize = 13.sp, color = PulseMuted) },
            shape = RoundedCornerShape(24.dp),
            colors = OutlinedTextFieldDefaults.colors(
              focusedContainerColor = PulseSoft,
              unfocusedContainerColor = PulseSoft,
              focusedBorderColor = PulsePrimary,
              unfocusedBorderColor = PulseBorder,
              focusedTextColor = PulseInk,
              unfocusedTextColor = PulseInk
            ),
            modifier = Modifier
              .weight(1f)
              .height(50.dp)
              .testTag("chat_input_field"),
            maxLines = 3
          )

          Spacer(modifier = Modifier.width(8.dp))

          Box(
            modifier = Modifier
              .size(46.dp)
              .background(if (inputText.isNotBlank() && !isLoading) PulseAccent else PulseSoft, CircleShape)
              .clip(CircleShape)
              .clickable(enabled = inputText.isNotBlank() && !isLoading) {
                val toSend = inputText.trim()
                if (toSend.isNotBlank()) {
                  viewModel.sendChatMessage(toSend)
                  inputText = ""
                }
              }
              .testTag("send_chat_button"),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.Send,
              contentDescription = "Send",
              tint = if (inputText.isNotBlank() && !isLoading) PulseOnAccent else PulseMuted,
              modifier = Modifier.size(18.dp)
            )
          }
        }
      }
    }
  }
}

@Composable
private fun ChatBubble(
  message: ChatMessage,
  modifier: Modifier = Modifier
) {
  val isUser = message.role == "user"
  val timeFormatted = remember(message.timestamp) {
    SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(message.timestamp))
  }

  Row(
    modifier = modifier.fillMaxWidth(),
    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
  ) {
    if (!isUser) {
      Box(
        modifier = Modifier
          .size(30.dp)
          .background(PulseLightTeal, CircleShape),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.Default.AutoAwesome,
          contentDescription = null,
          tint = PulsePrimary,
          modifier = Modifier.size(16.dp)
        )
      }
      Spacer(modifier = Modifier.width(8.dp))
    }

    Column(
      horizontalAlignment = if (isUser) Alignment.End else Alignment.Start,
      modifier = Modifier.fillMaxWidth(0.85f)
    ) {
      Surface(
        shape = RoundedCornerShape(
          topStart = 14.dp,
          topEnd = 14.dp,
          bottomStart = if (isUser) 14.dp else 2.dp,
          bottomEnd = if (isUser) 2.dp else 14.dp
        ),
        color = if (isUser) PulseAccent else PulseSurface,
        border = if (isUser) null else BorderStroke(1.dp, PulseBorder),
        shadowElevation = if (isUser) 0.dp else 1.dp
      ) {
        Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
          if (!isUser && message.modelUsed != null) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.padding(bottom = 4.dp)
            ) {
              Box(
                modifier = Modifier
                  .background(PulseLightTeal, RoundedCornerShape(4.dp))
                  .padding(horizontal = 5.dp, vertical = 1.dp)
              ) {
                Text(
                  text = message.modelUsed,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = PulsePrimary
                )
              }
            }
          }

          Text(
            text = message.text,
            fontSize = 14.sp,
            lineHeight = 20.sp,
            color = if (isUser) PulseOnAccent else PulseInk,
            fontWeight = if (isUser) FontWeight.Medium else FontWeight.Normal
          )
        }
      }

      Text(
        text = timeFormatted,
        fontSize = 10.sp,
        color = PulseMuted,
        modifier = Modifier.padding(top = 2.dp, start = 4.dp, end = 4.dp)
      )
    }
  }
}
