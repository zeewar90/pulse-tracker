package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.FormatListBulleted
import androidx.compose.material.icons.automirrored.outlined.FormatListBulleted
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.CheckCircleOutline
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.PulseAccent
import com.example.ui.theme.PulseBorder
import com.example.ui.theme.PulseMuted
import com.example.ui.theme.PulseOnAccent
import com.example.ui.theme.PulsePrimary
import com.example.ui.theme.PulseSurface

enum class TabDestination(
  val route: String,
  val label: String,
  val filledIcon: ImageVector,
  val outlinedIcon: ImageVector
) {
  TODAY("today", "Today", Icons.Filled.CheckCircle, Icons.Outlined.CheckCircleOutline),
  HABITS("habits", "Habits", Icons.AutoMirrored.Filled.FormatListBulleted, Icons.AutoMirrored.Outlined.FormatListBulleted),
  STATS("stats", "Stats", Icons.Filled.BarChart, Icons.Outlined.BarChart),
  SETTINGS("settings", "Settings", Icons.Filled.Settings, Icons.Outlined.Settings)
}

@Composable
fun PulseTabBar(
  currentRoute: String,
  onNavigate: (String) -> Unit,
  onAddClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Box(
    modifier = modifier.fillMaxWidth(),
    contentAlignment = Alignment.BottomCenter
  ) {
    Surface(
      modifier = Modifier.fillMaxWidth(),
      color = PulseSurface,
      tonalElevation = 0.dp
    ) {
      Column {
        HorizontalDivider(
          thickness = 1.dp,
          color = PulseBorder
        )

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .height(64.dp)
            .padding(horizontal = 4.dp),
          horizontalArrangement = Arrangement.SpaceAround,
          verticalAlignment = Alignment.CenterVertically
        ) {
          // Tab 1: Today
          TabItem(
            destination = TabDestination.TODAY,
            isSelected = currentRoute == TabDestination.TODAY.route,
            onSelect = { onNavigate(TabDestination.TODAY.route) },
            modifier = Modifier.weight(1f)
          )

          // Tab 2: Habits
          TabItem(
            destination = TabDestination.HABITS,
            isSelected = currentRoute == TabDestination.HABITS.route,
            onSelect = { onNavigate(TabDestination.HABITS.route) },
            modifier = Modifier.weight(1f)
          )

          // Center gap for Add button
          Spacer(modifier = Modifier.size(52.dp))

          // Tab 3: Stats
          TabItem(
            destination = TabDestination.STATS,
            isSelected = currentRoute == TabDestination.STATS.route,
            onSelect = { onNavigate(TabDestination.STATS.route) },
            modifier = Modifier.weight(1f)
          )

          // Tab 4: Settings
          TabItem(
            destination = TabDestination.SETTINGS,
            isSelected = currentRoute == TabDestination.SETTINGS.route,
            onSelect = { onNavigate(TabDestination.SETTINGS.route) },
            modifier = Modifier.weight(1f)
          )
        }
      }
    }

    // Centered elevated floating "+" button (accent colored circle)
    Box(
      modifier = Modifier
        .offset(y = (-20).dp)
        .size(52.dp)
        .shadow(elevation = 4.dp, shape = CircleShape)
        .background(PulseAccent, CircleShape)
        .testTag("floating_add_habit_button")
        .clickable(
          interactionSource = remember { MutableInteractionSource() },
          indication = ripple(bounded = false, radius = 26.dp),
          onClick = onAddClick
        ),
      contentAlignment = Alignment.Center
    ) {
      Icon(
        imageVector = Icons.Default.Add,
        contentDescription = "Add Habit",
        tint = PulseOnAccent,
        modifier = Modifier.size(26.dp)
      )
    }
  }
}

@Composable
private fun TabItem(
  destination: TabDestination,
  isSelected: Boolean,
  onSelect: () -> Unit,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .size(width = 64.dp, height = 56.dp)
      .testTag("tab_${destination.route}")
      .clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = ripple(bounded = false, radius = 28.dp),
        onClick = onSelect
      ),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    Icon(
      imageVector = if (isSelected) destination.filledIcon else destination.outlinedIcon,
      contentDescription = destination.label,
      tint = if (isSelected) PulsePrimary else PulseMuted,
      modifier = Modifier.size(22.dp)
    )
    Text(
      text = destination.label,
      fontSize = 11.sp,
      fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
      color = if (isSelected) PulsePrimary else PulseMuted,
      modifier = Modifier.padding(top = 2.dp)
    )
  }
}
