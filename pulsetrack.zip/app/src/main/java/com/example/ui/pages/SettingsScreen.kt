package com.example.ui.pages

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.HabitViewModel
import com.example.ui.components.PulseInputField
import com.example.ui.theme.PulseAccent
import com.example.ui.theme.PulseBg
import com.example.ui.theme.PulseBorder
import com.example.ui.theme.PulseDestructive
import com.example.ui.theme.PulseInk
import com.example.ui.theme.PulseLightAmber
import com.example.ui.theme.PulseLightTeal
import com.example.ui.theme.PulseMuted
import com.example.ui.theme.PulseOnAccent
import com.example.ui.theme.PulsePrimary
import com.example.ui.theme.PulseSoft
import com.example.ui.theme.PulseSurface

@Composable
fun SettingsScreen(
  viewModel: HabitViewModel,
  onSignOut: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val currentName by viewModel.userName.collectAsState()
  val notificationsEnabled by viewModel.notificationsEnabled.collectAsState()
  val eveningReviewEnabled by viewModel.eveningReviewEnabled.collectAsState()
  val currentUser by viewModel.currentUser.collectAsState()
  val syncStatus by viewModel.syncStatus.collectAsState()
  val customApiKey by viewModel.customApiKey.collectAsState()

  var editingName by remember(currentName) { mutableStateOf(currentName) }
  var isNameSaved by remember { mutableStateOf(false) }
  var apiKeyInput by remember(customApiKey) { mutableStateOf(customApiKey) }
  var isKeySaved by remember { mutableStateOf(false) }
  var showResetDialog by remember { mutableStateOf(false) }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(PulseBg)
  ) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .testTag("settings_screen_list"),
      contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 96.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // Title
      item {
        Column {
          Text(
            text = "Settings & Cloud",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = PulseInk,
            letterSpacing = (-0.5).sp
          )
          Text(
            text = "Firebase Auth, Firestore sync & Gemini models",
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            color = PulseMuted,
            modifier = Modifier.padding(top = 2.dp)
          )
        }
      }

      // Firebase Auth & Cloud Sync Card
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = PulseSurface),
          border = BorderStroke(1.dp, PulseBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(40.dp)
                    .background(PulseLightTeal, CircleShape),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(
                    imageVector = Icons.Default.CloudSync,
                    contentDescription = null,
                    tint = PulsePrimary,
                    modifier = Modifier.size(22.dp)
                  )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                  Text(
                    text = "Firebase Auth & Firestore",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = PulseInk
                  )
                  Text(
                    text = syncStatus,
                    fontSize = 12.sp,
                    color = PulsePrimary,
                    fontWeight = FontWeight.Medium
                  )
                }
              }

              if (currentUser != null) {
                Box(
                  modifier = Modifier
                    .background(PulseLightTeal, RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                  Text(
                    text = "Connected",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = PulsePrimary
                  )
                }
              }
            }

            if (currentUser != null) {
              // Signed in state
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .background(PulseSoft, RoundedCornerShape(10.dp))
                  .padding(12.dp)
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Box(
                    modifier = Modifier
                      .size(36.dp)
                      .background(PulsePrimary, CircleShape),
                    contentAlignment = Alignment.Center
                  ) {
                    Text(
                      text = (currentUser!!.displayName?.take(1) ?: "U").uppercase(),
                      color = PulseOnAccent,
                      fontWeight = FontWeight.Bold,
                      fontSize = 16.sp
                    )
                  }
                  Spacer(modifier = Modifier.width(10.dp))
                  Column {
                    Text(
                      text = currentUser!!.displayName ?: "Signed-in User",
                      fontSize = 14.sp,
                      fontWeight = FontWeight.SemiBold,
                      color = PulseInk
                    )
                    Text(
                      text = currentUser!!.email ?: "UID: ${currentUser!!.uid.take(12)}...",
                      fontSize = 12.sp,
                      color = PulseMuted
                    )
                  }
                }
              }

              Button(
                onClick = { viewModel.signOut() },
                colors = ButtonDefaults.buttonColors(
                  containerColor = PulseSoft,
                  contentColor = PulseInk
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                  .fillMaxWidth()
                  .height(44.dp)
                  .testTag("firebase_sign_out_button")
              ) {
                Text("Sign Out from Firebase", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
              }
            } else {
              // Sign in buttons
              Text(
                text = "Sign in to persist and sync your habits, streaks, and vision boards securely across devices with Firebase Firestore.",
                fontSize = 12.sp,
                color = PulseMuted,
                lineHeight = 16.sp
              )

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
              ) {
                Button(
                  onClick = { viewModel.signInWithGoogle(context) },
                  colors = ButtonDefaults.buttonColors(
                    containerColor = PulseAccent,
                    contentColor = PulseOnAccent
                  ),
                  shape = RoundedCornerShape(10.dp),
                  modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("google_sign_in_button")
                ) {
                  Icon(Icons.Default.AccountCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("Google Sign-In", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                }

                OutlinedButton(
                  onClick = { viewModel.signInFast() },
                  shape = RoundedCornerShape(10.dp),
                  border = BorderStroke(1.dp, PulseBorder),
                  modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("quick_auth_button")
                ) {
                  Text("Quick Connect", color = PulseInk, fontSize = 13.sp)
                }
              }
            }
          }
        }
      }

      // Gemini AI Models Card
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = PulseSurface),
          border = BorderStroke(1.dp, PulseBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(40.dp)
                  .background(PulseLightAmber, CircleShape),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = Icons.Default.AutoAwesome,
                  contentDescription = null,
                  tint = PulseAccent,
                  modifier = Modifier.size(22.dp)
                )
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = "Gemini Models",
                  fontSize = 16.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = PulseInk
                )
                Text(
                  text = "Configured AI Engines",
                  fontSize = 12.sp,
                  color = PulseMuted
                )
              }
            }

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
              ModelInfoRow(model = "gemini-3.5-flash", purpose = "Daily Habit Coach (General)")
              ModelInfoRow(model = "gemini-3.1-pro-preview", purpose = "Deep Behavioral Strategist (Complex)")
              ModelInfoRow(model = "gemini-3.1-flash-lite", purpose = "Quick Habit Pep-Talk (Fast)")
              ModelInfoRow(model = "gemini-3.1-flash-image-preview", purpose = "Vision Art Generation & Editing")
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Custom API Key Override (Optional)
            Text(
              text = "Custom Gemini API Key (Optional)",
              fontSize = 13.sp,
              fontWeight = FontWeight.SemiBold,
              color = PulseInk
            )
            Text(
              text = "Keys are securely injected via AI Studio Secrets. You can also enter or override your key below:",
              fontSize = 11.sp,
              color = PulseMuted
            )

            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically
            ) {
              OutlinedTextField(
                value = apiKeyInput,
                onValueChange = {
                  apiKeyInput = it
                  isKeySaved = false
                },
                placeholder = { Text("Paste AI Studio API Key...", fontSize = 12.sp, color = PulseMuted) },
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                  focusedContainerColor = PulseSoft,
                  unfocusedContainerColor = PulseSoft,
                  focusedBorderColor = PulsePrimary,
                  unfocusedBorderColor = PulseBorder,
                  focusedTextColor = PulseInk,
                  unfocusedTextColor = PulseInk
                ),
                modifier = Modifier
                  .weight(1f)
                  .height(52.dp)
                  .testTag("gemini_key_input"),
                singleLine = true
              )

              Spacer(modifier = Modifier.width(8.dp))

              Button(
                onClick = {
                  viewModel.setCustomApiKey(apiKeyInput.trim())
                  isKeySaved = true
                },
                colors = ButtonDefaults.buttonColors(
                  containerColor = PulsePrimary,
                  contentColor = PulseOnAccent
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.height(52.dp)
              ) {
                Text(if (isKeySaved) "Saved" else "Save")
              }
            }
          }
        }
      }

      // Profile Name Card
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = PulseSurface),
          border = BorderStroke(1.dp, PulseBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp)
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.padding(bottom = 14.dp)
            ) {
              Box(
                modifier = Modifier
                  .size(40.dp)
                  .background(PulseLightTeal, CircleShape),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = Icons.Default.Person,
                  contentDescription = null,
                  tint = PulsePrimary,
                  modifier = Modifier.size(22.dp)
                )
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text(
                  text = "Display Name",
                  fontSize = 16.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = PulseInk
                )
                Text(
                  text = "Used for personal daily greetings & AI coaching",
                  fontSize = 12.sp,
                  color = PulseMuted
                )
              }
            }

            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(modifier = Modifier.weight(1f)) {
                PulseInputField(
                  value = editingName,
                  onValueChange = {
                    editingName = it
                    isNameSaved = false
                  },
                  label = "",
                  placeholder = "Your name",
                  testTag = "profile_name_input"
                )
              }

              Spacer(modifier = Modifier.width(10.dp))

              Button(
                onClick = {
                  if (editingName.isNotBlank()) {
                    viewModel.updateUserName(editingName.trim())
                    isNameSaved = true
                  }
                },
                colors = ButtonDefaults.buttonColors(
                  containerColor = PulsePrimary,
                  contentColor = PulseOnAccent
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                  .height(52.dp)
                  .testTag("save_profile_button")
              ) {
                if (isNameSaved) {
                  Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                }
                Text(if (isNameSaved) "Saved" else "Save")
              }
            }
          }
        }
      }

      // Notifications Card
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = PulseSurface),
          border = BorderStroke(1.dp, PulseBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.Notifications,
                contentDescription = null,
                tint = PulsePrimary,
                modifier = Modifier.size(20.dp)
              )
              Spacer(modifier = Modifier.width(10.dp))
              Text(
                text = "Notifications & Reminders",
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
                color = PulseInk
              )
            }

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = "Morning Reminder",
                  fontSize = 14.sp,
                  fontWeight = FontWeight.Medium,
                  color = PulseInk
                )
                Text(
                  text = "Gentle nudge at 8:00 AM to check your habits",
                  fontSize = 12.sp,
                  color = PulseMuted
                )
              }
              Switch(
                checked = notificationsEnabled,
                onCheckedChange = { viewModel.toggleNotifications(it) },
                colors = SwitchDefaults.colors(
                  checkedThumbColor = PulseOnAccent,
                  checkedTrackColor = PulsePrimary,
                  uncheckedThumbColor = PulseMuted,
                  uncheckedTrackColor = PulseSoft
                ),
                modifier = Modifier.testTag("morning_notification_switch")
              )
            }

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = "Evening Reflection",
                  fontSize = 14.sp,
                  fontWeight = FontWeight.Medium,
                  color = PulseInk
                )
                Text(
                  text = "Review completed streaks at 9:00 PM",
                  fontSize = 12.sp,
                  color = PulseMuted
                )
              }
              Switch(
                checked = eveningReviewEnabled,
                onCheckedChange = { viewModel.toggleEveningReview(it) },
                colors = SwitchDefaults.colors(
                  checkedThumbColor = PulseOnAccent,
                  checkedTrackColor = PulsePrimary,
                  uncheckedThumbColor = PulseMuted,
                  uncheckedTrackColor = PulseSoft
                ),
                modifier = Modifier.testTag("evening_notification_switch")
              )
            }
          }
        }
      }

      // App Theme & About Card
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = PulseSurface),
          border = BorderStroke(1.dp, PulseBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.Info,
                contentDescription = null,
                tint = PulsePrimary,
                modifier = Modifier.size(20.dp)
              )
              Spacer(modifier = Modifier.width(10.dp))
              Text(
                text = "About PulseTrack",
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
                color = PulseInk
              )
            }

            Text(
              text = "PulseTrack v1.1.0\nA mindful habit tracker featuring Google Sign-In with Firebase Auth, Cloud Firestore persistence, multi-turn AI habit coaching, and text-to-image vision art.",
              fontSize = 13.sp,
              lineHeight = 18.sp,
              color = PulseMuted
            )
          }
        }
      }

      // Reset / Sign Out Section
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = PulseSurface),
          border = BorderStroke(1.dp, PulseBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            Text(
              text = "Reset & Exit",
              fontSize = 16.sp,
              fontWeight = FontWeight.SemiBold,
              color = PulseInk
            )

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              OutlinedButton(
                onClick = { showResetDialog = true },
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, PulseBorder),
                modifier = Modifier
                  .weight(1f)
                  .height(48.dp)
                  .testTag("reset_data_button")
              ) {
                Icon(
                  imageVector = Icons.Default.RestartAlt,
                  contentDescription = null,
                  tint = PulseInk,
                  modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Reset Data", color = PulseInk, fontSize = 13.sp)
              }

              Button(
                onClick = onSignOut,
                colors = ButtonDefaults.buttonColors(
                  containerColor = PulseAccent,
                  contentColor = PulseOnAccent
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                  .weight(1f)
                  .height(48.dp)
                  .testTag("sign_out_button")
              ) {
                Text("Sign Out", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
              }
            }
          }
        }
      }
    }
  }

  // Reset Confirmation Dialog
  if (showResetDialog) {
    AlertDialog(
      onDismissRequest = { showResetDialog = false },
      containerColor = PulseSurface,
      shape = RoundedCornerShape(12.dp),
      title = {
        Text("Reset to Sample Data?", fontWeight = FontWeight.Bold, color = PulseInk)
      },
      text = {
        Text(
          "This will reset all habits to default sample habits (Drink water, Morning stretch, Read 20 pages, etc.) and reset your streaks.",
          color = PulseInk,
          fontSize = 14.sp
        )
      },
      confirmButton = {
        Button(
          onClick = {
            viewModel.resetData()
            showResetDialog = false
          },
          colors = ButtonDefaults.buttonColors(
            containerColor = PulseAccent,
            contentColor = PulseOnAccent
          ),
          shape = RoundedCornerShape(8.dp)
        ) {
          Text("Reset")
        }
      },
      dismissButton = {
        TextButton(onClick = { showResetDialog = false }) {
          Text("Cancel", color = PulseMuted)
        }
      }
    )
  }
}

@Composable
private fun ModelInfoRow(model: String, purpose: String) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .background(PulseSoft, RoundedCornerShape(6.dp))
      .padding(horizontal = 10.dp, vertical = 6.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(
      text = model,
      fontSize = 11.sp,
      fontWeight = FontWeight.Bold,
      color = PulsePrimary
    )
    Text(
      text = purpose,
      fontSize = 11.sp,
      color = PulseInk
    )
  }
}
