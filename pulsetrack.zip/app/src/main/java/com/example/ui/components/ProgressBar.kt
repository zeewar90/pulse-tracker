package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.PulsePrimary
import com.example.ui.theme.PulseSoft

@Composable
fun PulseProgressBar(
  progress: Float,
  modifier: Modifier = Modifier,
  height: Dp = 8.dp,
  trackColor: Color = PulseSoft,
  progressColor: Color = PulsePrimary
) {
  val animatedProgress by animateFloatAsState(
    targetValue = progress.coerceIn(0f, 1f),
    animationSpec = tween(durationMillis = 400),
    label = "progressAnim"
  )

  Box(
    modifier = modifier
      .fillMaxWidth()
      .height(height)
      .clip(RoundedCornerShape(height / 2))
      .background(trackColor)
  ) {
    if (animatedProgress > 0f) {
      Box(
        modifier = Modifier
          .fillMaxWidth(animatedProgress)
          .fillMaxHeight()
          .clip(RoundedCornerShape(height / 2))
          .background(progressColor)
      )
    }
  }
}
