package com.example.ui.pages

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.SettingsVoice
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.gemini.LiveSessionState
import com.example.data.gemini.LiveTranscriptItem
import com.example.ui.HabitViewModel
import com.example.ui.theme.PulseAccent
import com.example.ui.theme.PulseBg
import com.example.ui.theme.PulseBorder
import com.example.ui.theme.PulseInk
import com.example.ui.theme.PulseLightAmber
import com.example.ui.theme.PulseLightTeal
import com.example.ui.theme.PulseMuted
import com.example.ui.theme.PulseOnAccent
import com.example.ui.theme.PulsePrimary
import com.example.ui.theme.PulseSoft
import com.example.ui.theme.PulseSurface

@Composable
fun LiveVoiceScreen(
  viewModel: HabitViewModel,
  onNavigateBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val sessionState by viewModel.liveSessionState.collectAsState()
  val transcripts by viewModel.liveTranscripts.collectAsState()
  val isMuted by viewModel.isLiveMuted.collectAsState()
  val selectedVoice by viewModel.liveSelectedVoice.collectAsState()
  val amplitude by viewModel.liveAudioAmplitude.collectAsState()
  val streamingText by viewModel.liveStreamingText.collectAsState()

  var hasAudioPermission by remember {
    mutableStateOf(
      ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    )
  }

  val permissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission()
  ) { isGranted ->
    hasAudioPermission = isGranted
    if (isGranted) {
      viewModel.startLiveSession()
    }
  }

  var textInput by remember { mutableStateOf("") }
  var showVoiceMenu by remember { mutableStateOf(false) }
  val transcriptListState = rememberLazyListState()

  // Start live session on entry if permission is granted
  LaunchedEffect(Unit) {
    if (hasAudioPermission) {
      viewModel.startLiveSession()
    } else {
      permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }
  }

  // Auto-scroll transcript to bottom
  LaunchedEffect(transcripts.size, streamingText) {
    if (transcripts.isNotEmpty()) {
      transcriptListState.animateScrollToItem(transcripts.size - 1)
    }
  }

  // End session when leaving screen
  DisposableEffect(Unit) {
    onDispose {
      viewModel.endLiveSession()
    }
  }

  val starterPrompts = listOf(
    "How do I beat morning resistance?",
    "Review my habit consistency today",
    "Give me a 2-minute motivational boost",
    "How can I stack my habits effectively?",
    "I skipped a habit today, what should I do?"
  )

  Surface(
    modifier = modifier
      .fillMaxSize()
      .background(PulseBg)
      .imePadding(),
    color = PulseBg
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 16.dp, vertical = 12.dp),
      verticalArrangement = Arrangement.SpaceBetween
    ) {
      // 1. Top Header Bar
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          IconButton(
            onClick = {
              viewModel.endLiveSession()
              onNavigateBack()
            },
            modifier = Modifier
              .size(44.dp)
              .testTag("live_voice_back_button")
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "End Call & Return",
              tint = PulseInk,
              modifier = Modifier.size(24.dp)
            )
          }

          Spacer(modifier = Modifier.width(6.dp))

          Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = "Coach Live Voice",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = PulseInk
              )
              Spacer(modifier = Modifier.width(6.dp))
              Box(
                modifier = Modifier
                  .background(PulseLightTeal, RoundedCornerShape(6.dp))
                  .padding(horizontal = 6.dp, vertical = 2.dp)
              ) {
                Text(
                  text = "gemini-3.8-live",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = PulsePrimary
                )
              }
            }
            Text(
              text = "Real-time bidirectional live speech",
              fontSize = 12.sp,
              color = PulseMuted
            )
          }
        }

        // Voice Persona Selector
        Box {
          Surface(
            shape = RoundedCornerShape(20.dp),
            color = PulseSoft,
            border = BorderStroke(1.dp, PulseBorder),
            modifier = Modifier
              .clickable { showVoiceMenu = true }
              .testTag("voice_persona_picker")
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.SettingsVoice,
                contentDescription = null,
                tint = PulsePrimary,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = selectedVoice,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = PulseInk
              )
            }
          }

          DropdownMenu(
            expanded = showVoiceMenu,
            onDismissRequest = { showVoiceMenu = false }
          ) {
            viewModel.availableVoices.forEach { persona ->
              DropdownMenuItem(
                text = {
                  Column {
                    Text(
                      text = persona.displayName,
                      fontWeight = if (selectedVoice == persona.voiceName) FontWeight.Bold else FontWeight.Normal,
                      color = if (selectedVoice == persona.voiceName) PulsePrimary else PulseInk
                    )
                    Text(
                      text = persona.description,
                      fontSize = 11.sp,
                      color = PulseMuted
                    )
                  }
                },
                onClick = {
                  viewModel.setLiveVoice(persona.voiceName)
                  showVoiceMenu = false
                }
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // 2. Center Waveform Pulse & Visualizer
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .weight(0.42f),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
      ) {
        LiveAudioVisualizer(
          state = sessionState,
          amplitude = amplitude,
          isMuted = isMuted,
          streamingText = streamingText
        )

        Spacer(modifier = Modifier.height(14.dp))

        // State label
        val statusText = when (sessionState) {
          LiveSessionState.CONNECTING -> "Connecting to gemini-3.8-live..."
          LiveSessionState.CONNECTED -> "Ready • Start speaking"
          LiveSessionState.LISTENING -> if (isMuted) "Microphone Muted" else "Listening to your voice..."
          LiveSessionState.THINKING -> "Coach Live is thinking..."
          LiveSessionState.SPEAKING -> "Coach Live is speaking..."
          LiveSessionState.ERROR -> "Connection paused • Tap to reconnect"
          LiveSessionState.DISCONNECTED -> "Session disconnected"
        }

        val statusColor = when (sessionState) {
          LiveSessionState.SPEAKING -> PulseAccent
          LiveSessionState.LISTENING -> if (isMuted) PulseMuted else PulsePrimary
          LiveSessionState.THINKING -> PulseAccent
          LiveSessionState.ERROR -> Color(0xFFC04B3E)
          else -> PulseMuted
        }

        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .background(PulseSoft, RoundedCornerShape(16.dp))
            .padding(horizontal = 14.dp, vertical = 6.dp)
        ) {
          Box(
            modifier = Modifier
              .size(8.dp)
              .clip(CircleShape)
              .background(statusColor)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = statusText,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = PulseInk
          )
        }
      }

      // 3. Live Transcript Stream
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .weight(0.38f)
          .padding(vertical = 4.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = PulseSurface),
        border = BorderStroke(1.dp, PulseBorder)
      ) {
        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "Live Conversation Transcript",
              fontSize = 12.sp,
              fontWeight = FontWeight.SemiBold,
              color = PulseMuted
            )
            Icon(
              imageVector = Icons.AutoMirrored.Filled.VolumeUp,
              contentDescription = null,
              tint = PulseMuted,
              modifier = Modifier.size(16.dp)
            )
          }

          Spacer(modifier = Modifier.height(8.dp))

          if (transcripts.isEmpty() && streamingText.isEmpty()) {
            Box(
              modifier = Modifier.fillMaxSize(),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "Say \"Hi Coach\" or tap a starter below to begin your live voice dialogue with gemini-3.8-live.",
                fontSize = 13.sp,
                color = PulseMuted,
                modifier = Modifier.padding(horizontal = 16.dp)
              )
            }
          } else {
            LazyColumn(
              state = transcriptListState,
              modifier = Modifier.fillMaxSize(),
              verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              items(transcripts, key = { it.id }) { item ->
                TranscriptBubble(item = item)
              }

              // Ongoing streaming response
              if (streamingText.isNotEmpty()) {
                item {
                  TranscriptBubble(
                    item = LiveTranscriptItem(
                      isUser = false,
                      text = streamingText
                    )
                  )
                }
              }
            }
          }
        }
      }

      // 4. Quick Starter Chips
      LazyRow(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        items(starterPrompts) { prompt ->
          Surface(
            shape = RoundedCornerShape(16.dp),
            color = PulseSoft,
            border = BorderStroke(1.dp, PulseBorder),
            modifier = Modifier.clickable {
              viewModel.sendLiveUserMessage(prompt)
            }
          ) {
            Text(
              text = prompt,
              fontSize = 12.sp,
              color = PulseInk,
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
            )
          }
        }
      }

      // 5. Control Deck: Mic, Quick Text, End Call
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        // Text bar for quick typed question
        OutlinedTextField(
          value = textInput,
          onValueChange = { textInput = it },
          placeholder = { Text("Speak or type to Live API...", fontSize = 13.sp, color = PulseMuted) },
          singleLine = true,
          modifier = Modifier
            .weight(1f)
            .height(52.dp)
            .testTag("live_voice_text_input"),
          shape = RoundedCornerShape(26.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = PulseSurface,
            unfocusedContainerColor = PulseSurface,
            focusedBorderColor = PulsePrimary,
            unfocusedBorderColor = PulseBorder
          ),
          trailingIcon = {
            if (textInput.isNotBlank()) {
              IconButton(
                onClick = {
                  val query = textInput
                  textInput = ""
                  viewModel.sendLiveUserMessage(query)
                },
                modifier = Modifier.testTag("send_live_text_button")
              ) {
                Icon(
                  imageVector = Icons.AutoMirrored.Filled.Send,
                  contentDescription = "Send Message",
                  tint = PulsePrimary
                )
              }
            }
          }
        )

        Spacer(modifier = Modifier.width(10.dp))

        // Large Mic Toggle Button
        Box(
          modifier = Modifier
            .size(52.dp)
            .clip(CircleShape)
            .background(if (isMuted) PulseSoft else PulsePrimary)
            .border(1.dp, if (isMuted) PulseBorder else PulsePrimary, CircleShape)
            .clickable { viewModel.toggleLiveMute() }
            .testTag("live_mic_toggle_button"),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = if (isMuted) Icons.Default.MicOff else Icons.Default.Mic,
            contentDescription = if (isMuted) "Unmute Microphone" else "Mute Microphone",
            tint = if (isMuted) PulseInk else PulseOnAccent,
            modifier = Modifier.size(26.dp)
          )
        }

        Spacer(modifier = Modifier.width(10.dp))

        // End Call Button
        Box(
          modifier = Modifier
            .size(52.dp)
            .clip(CircleShape)
            .background(Color(0xFFE55342))
            .clickable {
              viewModel.endLiveSession()
              onNavigateBack()
            }
            .testTag("live_end_call_button"),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.CallEnd,
            contentDescription = "End Live Conversation",
            tint = Color.White,
            modifier = Modifier.size(24.dp)
          )
        }
      }
    }
  }
}

@Composable
private fun LiveAudioVisualizer(
  state: LiveSessionState,
  amplitude: Float,
  isMuted: Boolean,
  streamingText: String,
  modifier: Modifier = Modifier
) {
  val infiniteTransition = rememberInfiniteTransition(label = "pulse_rings")

  val pulseScale by infiniteTransition.animateFloat(
    initialValue = 1f,
    targetValue = if (state == LiveSessionState.SPEAKING || (state == LiveSessionState.LISTENING && !isMuted)) 1.25f else 1.05f,
    animationSpec = infiniteRepeatable(
      animation = tween(1200, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "scale"
  )

  val dynamicRingScale = 1f + (amplitude * 0.8f).coerceIn(0f, 0.6f)

  val primaryColor = when (state) {
    LiveSessionState.SPEAKING -> PulseAccent
    LiveSessionState.THINKING -> PulseAccent
    LiveSessionState.LISTENING -> if (isMuted) PulseMuted else PulsePrimary
    LiveSessionState.ERROR -> Color(0xFFC04B3E)
    else -> PulsePrimary
  }

  Box(
    modifier = modifier.size(160.dp),
    contentAlignment = Alignment.Center
  ) {
    // Outer concentric breathing ring 2
    Box(
      modifier = Modifier
        .size(150.dp)
        .scale(pulseScale * dynamicRingScale)
        .clip(CircleShape)
        .background(primaryColor.copy(alpha = 0.08f))
    )

    // Outer concentric breathing ring 1
    Box(
      modifier = Modifier
        .size(118.dp)
        .scale(pulseScale)
        .clip(CircleShape)
        .background(primaryColor.copy(alpha = 0.16f))
    )

    // Inner active orb
    Box(
      modifier = Modifier
        .size(80.dp)
        .clip(CircleShape)
        .background(primaryColor)
        .border(2.dp, PulseSurface, CircleShape),
      contentAlignment = Alignment.Center
    ) {
      Icon(
        imageVector = when (state) {
          LiveSessionState.SPEAKING -> Icons.Default.GraphicEq
          LiveSessionState.THINKING -> Icons.Default.RecordVoiceOver
          LiveSessionState.LISTENING -> if (isMuted) Icons.Default.MicOff else Icons.Default.Mic
          else -> Icons.Default.GraphicEq
        },
        contentDescription = "Live Voice Indicator",
        tint = PulseOnAccent,
        modifier = Modifier.size(38.dp)
      )
    }
  }
}

@Composable
private fun TranscriptBubble(
  item: LiveTranscriptItem,
  modifier: Modifier = Modifier
) {
  Row(
    modifier = modifier.fillMaxWidth(),
    horizontalArrangement = if (item.isUser) Arrangement.End else Arrangement.Start
  ) {
    Box(
      modifier = Modifier
        .fillMaxWidth(0.85f)
        .clip(
          RoundedCornerShape(
            topStart = 14.dp,
            topEnd = 14.dp,
            bottomStart = if (item.isUser) 14.dp else 2.dp,
            bottomEnd = if (item.isUser) 2.dp else 14.dp
          )
        )
        .background(if (item.isUser) PulseLightTeal else PulseSoft)
        .border(
          1.dp,
          if (item.isUser) PulsePrimary.copy(alpha = 0.25f) else PulseBorder,
          RoundedCornerShape(14.dp)
        )
        .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
      Column {
        Text(
          text = if (item.isUser) "You" else "Coach Live (gemini-3.8-live)",
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = if (item.isUser) PulsePrimary else PulseAccent
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = item.text,
          fontSize = 13.sp,
          color = PulseInk,
          lineHeight = 18.sp
        )
      }
    }
  }
}
