package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.LocalDrink
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.NightlightRound
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.PulseLightTeal
import com.example.ui.theme.PulsePrimary

data class HabitIconOption(
  val id: String,
  val label: String,
  val icon: ImageVector
)

object HabitIconRegistry {
  val options = listOf(
    HabitIconOption("water", "Hydration", Icons.Default.WaterDrop),
    HabitIconOption("stretch", "Stretch", Icons.Default.SelfImprovement),
    HabitIconOption("book", "Reading", Icons.Default.MenuBook),
    HabitIconOption("meditation", "Mindfulness", Icons.Default.Spa),
    HabitIconOption("walk", "Walking", Icons.Default.DirectionsWalk),
    HabitIconOption("run", "Running", Icons.Default.DirectionsRun),
    HabitIconOption("fitness", "Workout", Icons.Default.FitnessCenter),
    HabitIconOption("sleep", "Rest", Icons.Default.NightlightRound),
    HabitIconOption("code", "Coding", Icons.Default.Terminal),
    HabitIconOption("focus", "Focus", Icons.Default.Star)
  )

  fun getIcon(name: String): ImageVector {
    return options.find { it.id.equals(name, ignoreCase = true) }?.icon
      ?: Icons.Default.WaterDrop
  }
}

@Composable
fun HabitIconBadge(
  iconName: String,
  modifier: Modifier = Modifier,
  size: Dp = 44.dp,
  iconSize: Dp = 22.dp,
  backgroundColor: Color = PulseLightTeal,
  iconTint: Color = PulsePrimary
) {
  Box(
    modifier = modifier
      .size(size)
      .background(backgroundColor, RoundedCornerShape(10.dp)),
    contentAlignment = Alignment.Center
  ) {
    Icon(
      imageVector = HabitIconRegistry.getIcon(iconName),
      contentDescription = iconName,
      tint = iconTint,
      modifier = Modifier.size(iconSize)
    )
  }
}
