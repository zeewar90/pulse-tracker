package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.Habit
import com.example.data.HabitCompletion
import com.example.data.HabitEntity
import com.example.data.HabitRepository
import com.example.data.PulseTrackDatabase
import com.example.data.Streak
import com.example.data.firebase.FirebaseManager
import com.example.data.firebase.UserProfile
import com.example.data.gemini.ChatMessage
import com.example.data.gemini.CoachRole
import com.example.data.gemini.GeminiClient
import com.example.data.gemini.LiveSessionManager
import com.example.data.gemini.LiveSessionState
import com.example.data.gemini.LiveTranscriptItem
import com.example.data.gemini.LiveVoicePersona
import com.example.data.gemini.VisionImageItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.math.max

sealed interface HabitUiState {
  data object Loading : HabitUiState
  data class Success(
    val habits: List<Habit> = emptyList(),
    val completions: List<HabitCompletion> = emptyList(),
    val streaks: List<Streak> = emptyList(),
    val stats: HabitUiStats = HabitUiStats()
  ) : HabitUiState
  data class Error(val message: String) : HabitUiState
}

data class FocusSessionRecord(
  val id: Long = System.currentTimeMillis(),
  val habitId: Int?,
  val habitName: String,
  val durationMinutes: Int,
  val timestamp: Long = System.currentTimeMillis()
)

data class HabitUiStats(
  val totalHabits: Int = 0,
  val completedToday: Int = 0,
  val completionRateToday: Float = 0f,
  val weeklyOverallPercent: Int = 0,
  val bestStreak: Int = 0,
  val dayLabels: List<String> = listOf("M", "T", "W", "T", "F", "S", "S"),
  val dayCompletionRates: List<Float> = listOf(0.8f, 0.6f, 0.9f, 0.7f, 0.85f, 0.6f, 0.75f)
)

class HabitViewModel(application: Application) : AndroidViewModel(application) {
  private val repository: HabitRepository
  private val prefs = application.getSharedPreferences("pulse_track_prefs", Context.MODE_PRIVATE)

  val allHabits: StateFlow<List<HabitEntity>>
  val allCompletions: StateFlow<List<HabitCompletion>>
  val allStreaks: StateFlow<List<Streak>>
  val uiStats: StateFlow<HabitUiStats>
  val habitUiState: StateFlow<HabitUiState>

  // Focus Studio & Deep Work Session State
  private val _focusSessions = MutableStateFlow<List<FocusSessionRecord>>(
    listOf(
      FocusSessionRecord(
        id = 1L,
        habitId = null,
        habitName = "Morning Meditation",
        durationMinutes = 15,
        timestamp = System.currentTimeMillis() - 3600000L
      )
    )
  )
  val focusSessions: StateFlow<List<FocusSessionRecord>> = _focusSessions.asStateFlow()

  fun recordFocusSession(habit: Habit?, durationMinutes: Int) {
    val newRecord = FocusSessionRecord(
      id = System.currentTimeMillis(),
      habitId = habit?.id,
      habitName = habit?.name ?: "General Focus",
      durationMinutes = durationMinutes,
      timestamp = System.currentTimeMillis()
    )
    _focusSessions.value = listOf(newRecord) + _focusSessions.value
  }

  // Settings & Profile state
  private val _userName = MutableStateFlow(prefs.getString("user_name", "Alex Morgan") ?: "Alex Morgan")
  val userName: StateFlow<String> = _userName.asStateFlow()

  private val _notificationsEnabled = MutableStateFlow(prefs.getBoolean("notif_enabled", true))
  val notificationsEnabled: StateFlow<Boolean> = _notificationsEnabled.asStateFlow()

  private val _eveningReviewEnabled = MutableStateFlow(prefs.getBoolean("evening_enabled", true))
  val eveningReviewEnabled: StateFlow<Boolean> = _eveningReviewEnabled.asStateFlow()

  private val _customApiKey = MutableStateFlow(prefs.getString("gemini_key", "") ?: "")
  val customApiKey: StateFlow<String> = _customApiKey.asStateFlow()

  // Firebase Auth & Sync state
  val currentUser: StateFlow<UserProfile?> = FirebaseManager.currentUser
  val syncStatus: StateFlow<String> = FirebaseManager.syncStatus

  // Gemini Multi-Turn Chat state
  private val _selectedCoachRole = MutableStateFlow(CoachRole.DAILY_COACH)
  val selectedCoachRole: StateFlow<CoachRole> = _selectedCoachRole.asStateFlow()

  private val _chatMessages = MutableStateFlow<List<ChatMessage>>(
    listOf(
      ChatMessage(
        role = "model",
        text = "Hello ${_userName.value}! I'm Coach Pulse. Whether you're building a streak, tackling procrastination, or designing a new morning routine, I'm here to help. What habit are you working on today?",
        modelUsed = CoachRole.DAILY_COACH.modelId
      )
    )
  )
  val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

  private val _isChatLoading = MutableStateFlow(false)
  val isChatLoading: StateFlow<Boolean> = _isChatLoading.asStateFlow()

  private val _chatError = MutableStateFlow<String?>(null)
  val chatError: StateFlow<String?> = _chatError.asStateFlow()

  // Gemini Vision (Image Generation & Editing with gemini-3.1-flash-image-preview)
  private val _visionImages = MutableStateFlow<List<VisionImageItem>>(emptyList())
  val visionImages: StateFlow<List<VisionImageItem>> = _visionImages.asStateFlow()

  private val _isVisionLoading = MutableStateFlow(false)
  val isVisionLoading: StateFlow<Boolean> = _isVisionLoading.asStateFlow()

  private val _visionError = MutableStateFlow<String?>(null)
  val visionError: StateFlow<String?> = _visionError.asStateFlow()

  private val _selectedVisionForEdit = MutableStateFlow<VisionImageItem?>(null)
  val selectedVisionForEdit: StateFlow<VisionImageItem?> = _selectedVisionForEdit.asStateFlow()

  // Gemini Live API (gemini-3.8-live) Real-Time Voice Session
  val liveSessionManager by lazy { LiveSessionManager(application, viewModelScope) }
  val liveSessionState: StateFlow<LiveSessionState> get() = liveSessionManager.sessionState
  val liveTranscripts: StateFlow<List<LiveTranscriptItem>> get() = liveSessionManager.transcripts
  val liveSelectedVoice: StateFlow<String> get() = liveSessionManager.selectedVoice
  val isLiveMuted: StateFlow<Boolean> get() = liveSessionManager.isMuted
  val liveAudioAmplitude: StateFlow<Float> get() = liveSessionManager.audioAmplitude
  val liveStreamingText: StateFlow<String> get() = liveSessionManager.currentStreamingText
  val availableVoices: List<LiveVoicePersona> get() = liveSessionManager.availableVoices

  fun startLiveSession() {
    liveSessionManager.startSession(_customApiKey.value)
  }

  fun endLiveSession() {
    liveSessionManager.endSession()
  }

  fun sendLiveUserMessage(query: String) {
    liveSessionManager.sendUserMessage(query, _customApiKey.value)
  }

  fun toggleLiveMute() {
    liveSessionManager.toggleMute()
  }

  fun setLiveVoice(voiceName: String) {
    liveSessionManager.setVoice(voiceName)
  }

  init {
    val database = PulseTrackDatabase.getDatabase(application, viewModelScope)
    repository = HabitRepository(
      habitDao = database.habitDao(),
      habitCompletionDao = database.habitCompletionDao(),
      streakDao = database.streakDao()
    )

    // Initialize Firebase
    FirebaseManager.initialize(application)

    viewModelScope.launch {
      repository.ensureInitialData()
    }

    allHabits = repository.allHabits.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = emptyList()
    )

    allCompletions = repository.allCompletions.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = emptyList()
    )

    allStreaks = repository.allStreaks.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = emptyList()
    )

    uiStats = repository.allHabits.map { habits ->
      calculateStats(habits)
    }.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = HabitUiStats()
    )

    habitUiState = combine(
      repository.allHabits,
      repository.allCompletions,
      repository.allStreaks
    ) { habits, completions, streaks ->
      HabitUiState.Success(
        habits = habits,
        completions = completions,
        streaks = streaks,
        stats = calculateStats(habits)
      )
    }.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = HabitUiState.Loading
    )
  }

  // --- Streak Calculation & Habit Toggle Logic ---

  /**
   * Calculates new current streak and best streak based on completion toggle.
   */
  fun calculateStreak(currentStreak: Int, bestStreak: Int, nowCompleted: Boolean): Pair<Int, Int> {
    val newStreak = if (nowCompleted) {
      currentStreak + 1
    } else {
      max(0, currentStreak - 1)
    }
    val newBest = max(bestStreak, newStreak)
    return Pair(newStreak, newBest)
  }

  /**
   * Calculates consecutive completion streak by analyzing consecutive days in weeklyHistory string.
   */
  fun calculateStreakFromHistory(weeklyHistory: String): Int {
    val days = weeklyHistory.split(",").map { it.trim() == "1" }
    if (days.isEmpty()) return 0
    var streak = 0
    for (i in days.indices.reversed()) {
      if (days[i]) {
        streak++
      } else {
        break
      }
    }
    return streak
  }

  /**
   * Calculates best streak between current streak and previous best.
   */
  fun calculateBestStreak(currentStreak: Int, bestStreak: Int): Int {
    return max(currentStreak, bestStreak)
  }

  /**
   * Toggles the completion status of a habit, recalculating streak and bestStreak,
   * updating weekly history, and persisting to Room and Firestore.
   */
  fun toggleHabitCompletion(habit: Habit) {
    toggleHabit(habit)
  }

  // --- Habit Management with Firestore Sync ---

  fun toggleHabit(habit: HabitEntity) {
    viewModelScope.launch {
      val updated = repository.toggleHabitCompletion(habit)
      FirebaseManager.syncHabitToFirestore(updated)
    }
  }

  fun addHabit(name: String, iconName: String, frequency: String, dailyGoal: Int) {
    viewModelScope.launch {
      val newHabit = HabitEntity(
        name = name.trim(),
        iconName = iconName,
        frequency = frequency,
        dailyGoal = max(1, dailyGoal),
        streak = 0,
        completedToday = false,
        weeklyHistory = "0,0,0,0,0,0,0",
        bestStreak = 0
      )
      repository.insert(newHabit)
      FirebaseManager.syncHabitToFirestore(newHabit)
    }
  }

  fun updateHabit(habit: HabitEntity) {
    viewModelScope.launch {
      repository.update(habit)
      FirebaseManager.syncHabitToFirestore(habit)
    }
  }

  fun deleteHabit(habit: HabitEntity) {
    viewModelScope.launch {
      repository.delete(habit)
      FirebaseManager.deleteHabitFromFirestore(habit.id)
    }
  }

  fun resetData() {
    viewModelScope.launch {
      repository.resetToDefault()
      updateUserName("Alex Morgan")
      _notificationsEnabled.value = true
      _eveningReviewEnabled.value = true
    }
  }

  // --- Settings & Secrets ---

  fun updateUserName(name: String) {
    _userName.value = name
    prefs.edit().putString("user_name", name).apply()
  }

  fun setCustomApiKey(key: String) {
    _customApiKey.value = key.trim()
    prefs.edit().putString("gemini_key", key.trim()).apply()
  }

  fun toggleNotifications(enabled: Boolean) {
    _notificationsEnabled.value = enabled
    prefs.edit().putBoolean("notif_enabled", enabled).apply()
  }

  fun toggleEveningReview(enabled: Boolean) {
    _eveningReviewEnabled.value = enabled
    prefs.edit().putBoolean("evening_enabled", enabled).apply()
  }

  // --- Firebase Auth & Google Sign-In ---

  fun signInWithGoogle(context: Context) {
    viewModelScope.launch {
      FirebaseManager.signInWithGoogle(context)
    }
  }

  fun signInFast() {
    viewModelScope.launch {
      FirebaseManager.signInFast()
    }
  }

  fun signOut() {
    FirebaseManager.signOut()
  }

  // --- Gemini Multi-turn Chat ---

  fun selectCoachRole(role: CoachRole) {
    _selectedCoachRole.value = role
    val switchMessage = ChatMessage(
      role = "model",
      text = "Switched to **${role.title}** (${role.modelId} — ${role.speedLabel}). How can I support your routine?",
      modelUsed = role.modelId
    )
    _chatMessages.value = _chatMessages.value + switchMessage
  }

  fun sendChatMessage(text: String) {
    if (text.isBlank() || _isChatLoading.value) return

    val userMessage = ChatMessage(role = "user", text = text.trim())
    val historyBefore = _chatMessages.value
    _chatMessages.value = historyBefore + userMessage
    _isChatLoading.value = true
    _chatError.value = null

    val role = _selectedCoachRole.value
    val apiKey = _customApiKey.value

    viewModelScope.launch {
      val result = GeminiClient.sendChatMessage(
        history = historyBefore,
        currentMessage = text.trim(),
        role = role,
        customApiKey = apiKey
      )

      _isChatLoading.value = false
      result.onSuccess { replyText ->
        val modelMessage = ChatMessage(
          role = "model",
          text = replyText,
          modelUsed = role.modelId
        )
        _chatMessages.value = _chatMessages.value + modelMessage
      }.onFailure { error ->
        _chatError.value = error.message ?: "Failed to get response"
        val errorMessage = ChatMessage(
          role = "model",
          text = "⚠️ Coach notice: ${error.message ?: "Unable to contact Gemini."}\n\nTip: You can set a Gemini API key in Settings if not yet configured.",
          modelUsed = role.modelId
        )
        _chatMessages.value = _chatMessages.value + errorMessage
      }
    }
  }

  fun clearChat() {
    _chatMessages.value = listOf(
      ChatMessage(
        role = "model",
        text = "Chat history cleared. I'm ready for our next habit coaching session!",
        modelUsed = _selectedCoachRole.value.modelId
      )
    )
  }

  // --- Gemini Vision: Create & Edit Images using gemini-3.1-flash-image-preview ---

  fun generateVisionImage(prompt: String, aspectRatio: String = "1:1") {
    if (prompt.isBlank() || _isVisionLoading.value) return

    _isVisionLoading.value = true
    _visionError.value = null

    val apiKey = _customApiKey.value

    viewModelScope.launch {
      val result = GeminiClient.generateImage(
        prompt = prompt.trim(),
        aspectRatio = aspectRatio,
        customApiKey = apiKey
      )

      _isVisionLoading.value = false
      result.onSuccess { (base64Img, desc) ->
        val item = VisionImageItem(
          prompt = prompt.trim(),
          base64Data = base64Img,
          aspectRatio = aspectRatio,
          description = desc,
          isEdited = false
        )
        _visionImages.value = listOf(item) + _visionImages.value
        _selectedVisionForEdit.value = item
        FirebaseManager.saveVisionToFirestore(item)
      }.onFailure { error ->
        _visionError.value = error.message ?: "Image creation failed"
      }
    }
  }

  fun editVisionImage(original: VisionImageItem, editPrompt: String, aspectRatio: String = "1:1") {
    if (editPrompt.isBlank() || _isVisionLoading.value) return

    _isVisionLoading.value = true
    _visionError.value = null

    val apiKey = _customApiKey.value

    viewModelScope.launch {
      val result = GeminiClient.editImage(
        base64InputImage = original.base64Data,
        editPrompt = editPrompt.trim(),
        aspectRatio = aspectRatio,
        customApiKey = apiKey
      )

      _isVisionLoading.value = false
      result.onSuccess { (base64Img, desc) ->
        val editedItem = VisionImageItem(
          prompt = editPrompt.trim(),
          base64Data = base64Img,
          aspectRatio = aspectRatio,
          description = desc,
          isEdited = true,
          originalPrompt = original.prompt
        )
        _visionImages.value = listOf(editedItem) + _visionImages.value
        _selectedVisionForEdit.value = editedItem
        FirebaseManager.saveVisionToFirestore(editedItem)
      }.onFailure { error ->
        _visionError.value = error.message ?: "Image edit failed"
      }
    }
  }

  fun selectVisionForEdit(item: VisionImageItem?) {
    _selectedVisionForEdit.value = item
  }

  fun deleteVisionImage(id: String) {
    _visionImages.value = _visionImages.value.filter { it.id != id }
    if (_selectedVisionForEdit.value?.id == id) {
      _selectedVisionForEdit.value = null
    }
  }

  // --- Statistics Calculation ---

  fun calculateStats(habits: List<HabitEntity>): HabitUiStats {
    if (habits.isEmpty()) return HabitUiStats()

    val total = habits.size
    val completedToday = habits.count { it.completedToday }
    val todayRate = if (total > 0) completedToday.toFloat() / total.toFloat() else 0f

    val bestStreak = habits.maxOfOrNull { max(it.streak, it.bestStreak) } ?: 0

    val daySums = FloatArray(7) { 0f }
    var totalDaysTracked = 0
    var totalCompletions = 0

    for (habit in habits) {
      val weekly = habit.getWeeklyCompletionList()
      for (i in 0 until 7) {
        if (i < weekly.size && weekly[i]) {
          daySums[i] += 1f
          totalCompletions++
        }
        totalDaysTracked++
      }
    }

    val dayRates = daySums.map { count ->
      if (total > 0) (count / total.toFloat()).coerceIn(0f, 1f) else 0f
    }

    val weeklyOverallPercent = if (totalDaysTracked > 0) {
      ((totalCompletions.toFloat() / totalDaysTracked.toFloat()) * 100).toInt()
    } else 0

    return HabitUiStats(
      totalHabits = total,
      completedToday = completedToday,
      completionRateToday = todayRate,
      weeklyOverallPercent = weeklyOverallPercent.coerceIn(0, 100),
      bestStreak = bestStreak,
      dayLabels = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"),
      dayCompletionRates = dayRates
    )
  }
}
