package com.example.ui.pages

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.HabitEntity
import com.example.ui.HabitViewModel
import com.example.ui.components.HabitIconBadge
import com.example.ui.theme.PulseAccent
import com.example.ui.theme.PulseBg
import com.example.ui.theme.PulseBorder
import com.example.ui.theme.PulseDestructive
import com.example.ui.theme.PulseInk
import com.example.ui.theme.PulseLightAmber
import com.example.ui.theme.PulseLightTeal
import com.example.ui.theme.PulseMuted
import com.example.ui.theme.PulseOnAccent
import com.example.ui.theme.PulsePrimary
import com.example.ui.theme.PulseSoft
import com.example.ui.theme.PulseSurface

@Composable
fun HabitsScreen(
  habits: List<HabitEntity>,
  viewModel: HabitViewModel,
  onNavigateToAdd: () -> Unit,
  onEditHabit: (HabitEntity) -> Unit,
  modifier: Modifier = Modifier
) {
  var habitToDelete by remember { mutableStateOf<HabitEntity?>(null) }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(PulseBg)
  ) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .testTag("habits_screen_list"),
      contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 96.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      // Header Section
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = "Manage Habits",
              fontSize = 28.sp,
              fontWeight = FontWeight.Bold,
              color = PulseInk,
              letterSpacing = (-0.5).sp
            )
            Text(
              text = "${habits.size} active habit${if (habits.size != 1) "s" else ""}",
              fontSize = 14.sp,
              fontWeight = FontWeight.Medium,
              color = PulseMuted,
              modifier = Modifier.padding(top = 2.dp)
            )
          }

          Button(
            onClick = onNavigateToAdd,
            colors = ButtonDefaults.buttonColors(
              containerColor = PulseAccent,
              contentColor = PulseOnAccent
            ),
            shape = RoundedCornerShape(10.dp),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
            modifier = Modifier.testTag("add_habit_header_button")
          ) {
            Icon(
              imageVector = Icons.Default.Add,
              contentDescription = null,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "New Habit",
              fontSize = 13.sp,
              fontWeight = FontWeight.SemiBold
            )
          }
        }
        Spacer(modifier = Modifier.height(10.dp))
      }

      // Empty State
      if (habits.isEmpty()) {
        item {
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .padding(top = 24.dp),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = PulseSurface),
            border = BorderStroke(1.dp, PulseBorder)
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Icon(
                imageVector = Icons.Default.FormatListBulleted,
                contentDescription = null,
                tint = PulseMuted,
                modifier = Modifier.size(48.dp)
              )
              Spacer(modifier = Modifier.height(12.dp))
              Text(
                text = "No habits created yet",
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
                color = PulseInk
              )
              Text(
                text = "Track your routine and achieve your goals with PulseTrack.",
                fontSize = 13.sp,
                color = PulseMuted,
                modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
              )
              Button(
                onClick = onNavigateToAdd,
                colors = ButtonDefaults.buttonColors(
                  containerColor = PulseAccent,
                  contentColor = PulseOnAccent
                ),
                shape = RoundedCornerShape(10.dp)
              ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Add Your First Habit")
              }
            }
          }
        }
      } else {
        items(habits, key = { it.id }) { habit ->
          HabitManageRow(
            habit = habit,
            onEdit = { onEditHabit(habit) },
            onDelete = { habitToDelete = habit }
          )
        }
      }
    }
  }

  // Delete Confirmation Dialog
  habitToDelete?.let { habit ->
    AlertDialog(
      onDismissRequest = { habitToDelete = null },
      containerColor = PulseSurface,
      shape = RoundedCornerShape(12.dp),
      title = {
        Text(
          text = "Delete Habit",
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold,
          color = PulseInk
        )
      },
      text = {
        Text(
          text = "Are you sure you want to delete \"${habit.name}\"? All streak history will be permanently lost.",
          fontSize = 14.sp,
          color = PulseInk
        )
      },
      confirmButton = {
        Button(
          onClick = {
            viewModel.deleteHabit(habit)
            habitToDelete = null
          },
          colors = ButtonDefaults.buttonColors(
            containerColor = PulseDestructive,
            contentColor = PulseOnAccent
          ),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.testTag("confirm_delete_button")
        ) {
          Text("Delete")
        }
      },
      dismissButton = {
        TextButton(
          onClick = { habitToDelete = null },
          shape = RoundedCornerShape(8.dp)
        ) {
          Text("Cancel", color = PulseMuted)
        }
      }
    )
  }
}

@Composable
private fun HabitManageRow(
  habit: HabitEntity,
  onEdit: () -> Unit,
  onDelete: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .testTag("habit_manage_row_${habit.id}"),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = PulseSurface),
    border = BorderStroke(1.dp, PulseBorder),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.weight(1f)
      ) {
        HabitIconBadge(
          iconName = habit.iconName,
          size = 42.dp,
          iconSize = 22.dp,
          backgroundColor = PulseLightTeal,
          iconTint = PulsePrimary
        )

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = habit.name,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            color = PulseInk
          )

          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(top = 2.dp)
          ) {
            Text(
              text = habit.frequency,
              fontSize = 12.sp,
              fontWeight = FontWeight.Medium,
              color = PulsePrimary
            )

            Text(
              text = " • Goal: ${habit.dailyGoal}/day",
              fontSize = 12.sp,
              color = PulseMuted
            )

            Spacer(modifier = Modifier.width(8.dp))

            Box(
              modifier = Modifier
                .background(PulseLightAmber, RoundedCornerShape(4.dp))
                .padding(horizontal = 5.dp, vertical = 1.dp)
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Default.LocalFireDepartment,
                  contentDescription = null,
                  tint = PulseAccent,
                  modifier = Modifier.size(11.dp)
                )
                Spacer(modifier = Modifier.width(2.dp))
                Text(
                  text = "${habit.streak}d",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Medium,
                  color = PulseAccent
                )
              }
            }
          }
        }
      }

      // Actions: Edit and Delete
      Row(
        verticalAlignment = Alignment.CenterVertically
      ) {
        IconButton(
          onClick = onEdit,
          modifier = Modifier
            .size(38.dp)
            .testTag("edit_habit_${habit.id}")
        ) {
          Icon(
            imageVector = Icons.Default.Edit,
            contentDescription = "Edit Habit",
            tint = PulsePrimary,
            modifier = Modifier.size(18.dp)
          )
        }

        IconButton(
          onClick = onDelete,
          modifier = Modifier
            .size(38.dp)
            .testTag("delete_habit_${habit.id}")
        ) {
          Icon(
            imageVector = Icons.Default.DeleteOutline,
            contentDescription = "Delete Habit",
            tint = PulseMuted,
            modifier = Modifier.size(18.dp)
          )
        }
      }
    }
  }
}
