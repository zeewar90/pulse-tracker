package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.HabitEntity
import com.example.ui.theme.PulseAccent
import com.example.ui.theme.PulseBorder
import com.example.ui.theme.PulseInk
import com.example.ui.theme.PulseLightAmber
import com.example.ui.theme.PulseLightTeal
import com.example.ui.theme.PulseMuted
import com.example.ui.theme.PulseOnAccent
import com.example.ui.theme.PulsePrimary
import com.example.ui.theme.PulseSoft
import com.example.ui.theme.PulseSurface

@Composable
fun HabitCard(
  habit: HabitEntity,
  onToggleComplete: () -> Unit,
  modifier: Modifier = Modifier,
  onCardClick: (() -> Unit)? = null
) {
  val isCompleted = habit.completedToday

  val animatedAlpha by animateFloatAsState(
    targetValue = if (isCompleted) 0.65f else 1f,
    animationSpec = tween(durationMillis = 250),
    label = "habitAlpha"
  )

  val checkBgColor by animateColorAsState(
    targetValue = if (isCompleted) PulsePrimary else Color.Transparent,
    animationSpec = tween(durationMillis = 250),
    label = "checkBgColor"
  )

  val checkBorderColor by animateColorAsState(
    targetValue = if (isCompleted) PulsePrimary else PulseMuted.copy(alpha = 0.5f),
    animationSpec = tween(durationMillis = 250),
    label = "checkBorderColor"
  )

  Card(
    modifier = modifier
      .fillMaxWidth()
      .alpha(animatedAlpha)
      .testTag("habit_card_${habit.id}"),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(
      containerColor = PulseSurface
    ),
    border = BorderStroke(1.dp, PulseBorder),
    elevation = CardDefaults.cardElevation(
      defaultElevation = 1.dp
    ),
    onClick = {
      onCardClick?.invoke() ?: onToggleComplete()
    }
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 14.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      // Left: Icon + Habit Details
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.weight(1f)
      ) {
        HabitIconBadge(
          iconName = habit.iconName,
          size = 46.dp,
          iconSize = 24.dp,
          backgroundColor = if (isCompleted) PulseSoft else PulseLightTeal,
          iconTint = if (isCompleted) PulseMuted else PulsePrimary
        )

        Spacer(modifier = Modifier.width(14.dp))

        Column(
          horizontalAlignment = Alignment.Start,
          modifier = Modifier.weight(1f)
        ) {
          Text(
            text = habit.name,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            color = if (isCompleted) PulseMuted else PulseInk,
            textDecoration = if (isCompleted) TextDecoration.LineThrough else TextDecoration.None
          )

          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(top = 3.dp)
          ) {
            // Streak badge
            Box(
              modifier = Modifier
                .background(PulseLightAmber, RoundedCornerShape(6.dp))
                .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Default.LocalFireDepartment,
                  contentDescription = "Streak",
                  tint = PulseAccent,
                  modifier = Modifier.size(13.dp)
                )
                Spacer(modifier = Modifier.width(3.dp))
                Text(
                  text = "${habit.streak}d streak",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Medium,
                  color = PulseAccent
                )
              }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Frequency
            Text(
              text = habit.frequency,
              fontSize = 12.sp,
              color = PulseMuted
            )
          }
        }
      }

      Spacer(modifier = Modifier.width(12.dp))

      // Right: Custom Checkbox toggle with 44dp+ tap target
      Box(
        modifier = Modifier
          .size(48.dp)
          .testTag("habit_toggle_${habit.id}")
          .clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = ripple(bounded = false, radius = 24.dp),
            onClick = onToggleComplete
          ),
        contentAlignment = Alignment.Center
      ) {
        Box(
          modifier = Modifier
            .size(28.dp)
            .background(checkBgColor, CircleShape)
            .border(
              BorderStroke(1.5.dp, checkBorderColor),
              CircleShape
            ),
          contentAlignment = Alignment.Center
        ) {
          if (isCompleted) {
            Icon(
              imageVector = Icons.Default.Check,
              contentDescription = "Completed",
              tint = PulseOnAccent,
              modifier = Modifier
                .size(17.dp)
                .scale(1f)
            )
          }
        }
      }
    }
  }
}
