package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// PulseTrack Design Tokens
val PulseBg = Color(0xFFFBFAF7)         // Off-White / Page Background
val PulseSoft = Color(0xFFF0EFEA)       // Light Stone / Card Backgrounds
val PulsePrimary = Color(0xFF2E7D6B)    // Muted Teal / Headers, Active States, Links
val PulsePrimaryVariant = Color(0xFF236354)
val PulseAccent = Color(0xFFE8A04D)     // Warm Amber / Primary Buttons & Highlights ONLY
val PulseOnAccent = Color(0xFFFFFFFF)   // White / Text on Primary Buttons
val PulseInk = Color(0xFF3A3833)        // Charcoal / Normal Body Text
val PulseMuted = Color(0xFF8A8580)      // Soft Gray / Secondary Text
val PulseSurface = Color(0xFFFFFFFF)    // White / Inputs, Sheets, Raised Surfaces
val PulseBorder = Color(0x0F000000)     // Subtle border rgba(0,0,0,0.06)
val PulseDivider = Color(0x14000000)
val PulseSuccess = Color(0xFF2E7D6B)
val PulseCardShadow = Color(0x0A000000) // Soft shadow rgba(0,0,0,0.04)
val PulseLightTeal = Color(0xFFE8F3F0)
val PulseLightAmber = Color(0xFFFDF3E7)
val PulseDestructive = Color(0xFFD9534F)
