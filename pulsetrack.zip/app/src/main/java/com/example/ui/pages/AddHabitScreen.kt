package com.example.ui.pages

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.HabitEntity
import com.example.ui.HabitViewModel
import com.example.ui.components.HabitForm
import com.example.ui.theme.PulseBg
import com.example.ui.theme.PulseInk
import com.example.ui.theme.PulseMuted

@Composable
fun AddHabitScreen(
  viewModel: HabitViewModel,
  onNavigateBack: () -> Unit,
  habitToEdit: HabitEntity? = null,
  modifier: Modifier = Modifier
) {
  Box(
    modifier = modifier
      .fillMaxSize()
      .background(PulseBg)
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 40.dp)
    ) {
      // Header with Back button
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        IconButton(
          onClick = onNavigateBack,
          modifier = Modifier
            .size(44.dp)
            .testTag("add_habit_back_button")
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = "Back",
            tint = PulseInk
          )
        }

        Spacer(modifier = Modifier.width(8.dp))

        Column {
          Text(
            text = if (habitToEdit == null) "New Habit" else "Edit Habit",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = PulseInk,
            letterSpacing = (-0.3).sp
          )
          Text(
            text = if (habitToEdit == null) "Create a positive daily routine" else "Update habit parameters",
            fontSize = 13.sp,
            color = PulseMuted
          )
        }
      }

      Spacer(modifier = Modifier.height(24.dp))

      HabitForm(
        initialHabit = habitToEdit,
        onSubmit = { name, icon, frequency, goal ->
          if (habitToEdit == null) {
            viewModel.addHabit(name, icon, frequency, goal)
          } else {
            viewModel.updateHabit(
              habitToEdit.copy(
                name = name,
                iconName = icon,
                frequency = frequency,
                dailyGoal = goal
              )
            )
          }
          onNavigateBack()
        },
        onCancel = onNavigateBack
      )
    }
  }
}
