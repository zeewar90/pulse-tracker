package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// PulseTrack Light Theme strictly follows the requested palette:
// NO gradients, NO glassmorphism, NO dark themes, NO purple. Keep everything light and airy.
private val PulseColorScheme = lightColorScheme(
  primary = PulsePrimary,
  onPrimary = PulseOnAccent,
  primaryContainer = PulseLightTeal,
  onPrimaryContainer = PulsePrimary,
  secondary = PulseAccent,
  onSecondary = PulseOnAccent,
  secondaryContainer = PulseLightAmber,
  onSecondaryContainer = PulseInk,
  tertiary = PulseMuted,
  onTertiary = PulseOnAccent,
  background = PulseBg,
  onBackground = PulseInk,
  surface = PulseSurface,
  onSurface = PulseInk,
  surfaceVariant = PulseSoft,
  onSurfaceVariant = PulseMuted,
  outline = PulseBorder,
  outlineVariant = PulseDivider,
  error = PulseDestructive,
  onError = PulseOnAccent
)

@Composable
fun MyApplicationTheme(
  content: @Composable () -> Unit
) {
  val view = LocalView.current
  if (!view.isInEditMode) {
    SideEffect {
      val window = (view.context as? Activity)?.window
      if (window != null) {
        window.statusBarColor = PulseBg.toArgb()
        window.navigationBarColor = PulseSurface.toArgb()
        WindowCompat.getInsetsController(window, view).apply {
          isAppearanceLightStatusBars = true
          isAppearanceLightNavigationBars = true
        }
      }
    }
  }

  MaterialTheme(
    colorScheme = PulseColorScheme,
    typography = Typography,
    content = content
  )
}
