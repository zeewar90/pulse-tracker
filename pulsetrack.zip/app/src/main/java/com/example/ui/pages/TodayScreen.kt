package com.example.ui.pages

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.FormatListBulleted
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.HabitEntity
import com.example.ui.HabitViewModel
import com.example.ui.components.HabitCard
import com.example.ui.components.PulseProgressBar
import com.example.ui.theme.PulseAccent
import com.example.ui.theme.PulseBg
import com.example.ui.theme.PulseBorder
import com.example.ui.theme.PulseInk
import com.example.ui.theme.PulseLightAmber
import com.example.ui.theme.PulseLightTeal
import com.example.ui.theme.PulseMuted
import com.example.ui.theme.PulseOnAccent
import com.example.ui.theme.PulsePrimary
import com.example.ui.theme.PulseSoft
import com.example.ui.theme.PulseSurface
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TodayScreen(
  habits: List<HabitEntity>,
  viewModel: HabitViewModel,
  onNavigateToAdd: () -> Unit,
  onNavigateToFocus: () -> Unit = {},
  onNavigateToHabits: () -> Unit = {},
  onNavigateToSettings: () -> Unit = {},
  onNavigateToCoach: () -> Unit = onNavigateToFocus,
  onNavigateToVision: () -> Unit = onNavigateToFocus,
  onNavigateToLiveVoice: () -> Unit = onNavigateToFocus,
  modifier: Modifier = Modifier
) {
  val todayFormatted = remember {
    SimpleDateFormat("EEEE, MMM d", Locale.getDefault()).format(Date())
  }

  val currentUser by viewModel.currentUser.collectAsState()
  val syncStatus by viewModel.syncStatus.collectAsState()

  val total = habits.size
  val completed = habits.count { it.completedToday }
  val progress = if (total > 0) completed.toFloat() / total.toFloat() else 0f
  val percent = (progress * 100).toInt()

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(PulseBg)
  ) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .testTag("today_screen_list"),
      contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      // Top Header & Profile Status
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = "PulseTrack",
              fontSize = 24.sp,
              fontWeight = FontWeight.Bold,
              color = PulsePrimary,
              letterSpacing = (-0.5).sp
            )
            Text(
              text = todayFormatted,
              fontSize = 13.sp,
              fontWeight = FontWeight.Medium,
              color = PulseMuted
            )
          }

          Row(verticalAlignment = Alignment.CenterVertically) {
            // Cloud sync indicator / profile avatar
            Surface(
              shape = RoundedCornerShape(16.dp),
              color = PulseSoft,
              border = BorderStroke(1.dp, PulseBorder),
              modifier = Modifier
                .clip(RoundedCornerShape(16.dp))
                .clickable { onNavigateToSettings() }
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(
                  imageVector = Icons.Default.CloudDone,
                  contentDescription = "Cloud Status",
                  tint = if (currentUser != null) PulsePrimary else PulseMuted,
                  modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = if (currentUser != null) (currentUser!!.displayName?.take(8) ?: "Cloud") else "Offline",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = PulseInk
                )
              }
            }

            Spacer(modifier = Modifier.width(6.dp))

            IconButton(
              onClick = onNavigateToSettings,
              modifier = Modifier.size(36.dp).testTag("top_settings_button")
            ) {
              Icon(
                imageVector = Icons.Default.Settings,
                contentDescription = "Settings",
                tint = PulseInk,
                modifier = Modifier.size(20.dp)
              )
            }
          }
        }
      }

      // Hero Morning Routine Visual Banner
      item {
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .height(130.dp),
          shape = RoundedCornerShape(12.dp),
          border = BorderStroke(1.dp, PulseBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Box(modifier = Modifier.fillMaxSize()) {
            Image(
              painter = painterResource(id = R.drawable.img_today_hero),
              contentDescription = "Morning Habit Routine",
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxSize()
            )
            Box(
              modifier = Modifier
                .fillMaxSize()
                .background(
                  Brush.verticalGradient(
                    colors = listOf(Color.Transparent, Color(0x991E2A27))
                  )
                )
            )
            Column(
              modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(14.dp)
            ) {
              Text(
                text = "Small daily habits build extraordinary lives.",
                color = PulseOnAccent,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
              )
              Text(
                text = "Track your mindful routine with calm consistency",
                color = PulseOnAccent.copy(alpha = 0.85f),
                fontSize = 11.sp
              )
            }
          }
        }
      }

      // Quick Hub Chips (Focus Studio, Pomodoro, Habits)
      item {
        LazyRow(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          contentPadding = PaddingValues(horizontal = 2.dp)
        ) {
          item {
            Surface(
              shape = RoundedCornerShape(20.dp),
              color = PulseLightTeal,
              border = BorderStroke(1.dp, PulsePrimary.copy(alpha = 0.4f)),
              modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .clickable { onNavigateToFocus() }
                .testTag("today_quick_focus_chip")
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(Icons.Default.Timer, contentDescription = null, tint = PulsePrimary, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Focus Studio", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PulsePrimary)
              }
            }
          }

          item {
            Surface(
              shape = RoundedCornerShape(20.dp),
              color = PulseLightAmber,
              border = BorderStroke(1.dp, PulseAccent.copy(alpha = 0.4f)),
              modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .clickable { onNavigateToFocus() }
                .testTag("today_quick_pomodoro_chip")
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(Icons.Default.HourglassEmpty, contentDescription = null, tint = PulseAccent, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("25m Pomodoro", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = PulseAccent)
              }
            }
          }

          item {
            Surface(
              shape = RoundedCornerShape(20.dp),
              color = PulseSoft,
              border = BorderStroke(1.dp, PulseBorder),
              modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .clickable { onNavigateToHabits() }
                .testTag("today_quick_habits_chip")
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(Icons.AutoMirrored.Filled.FormatListBulleted, contentDescription = null, tint = PulseInk, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("All Habits", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = PulseInk)
              }
            }
          }

          item {
            Surface(
              shape = RoundedCornerShape(20.dp),
              color = PulseSoft,
              border = BorderStroke(1.dp, PulseBorder),
              modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .clickable { onNavigateToAdd() }
                .testTag("today_quick_add_chip")
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(Icons.Default.Add, contentDescription = null, tint = PulseInk, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("New Habit", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = PulseInk)
              }
            }
          }
        }
      }

      // Progress Highlight Card
      item {
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .testTag("today_progress_card"),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = PulseSoft),
          border = BorderStroke(1.dp, PulseBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp)
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(
                  text = "Today's Pulse",
                  fontSize = 16.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = PulseInk
                )
                Text(
                  text = if (total > 0) "$completed of $total habits completed" else "No habits tracked yet",
                  fontSize = 13.sp,
                  color = PulseMuted
                )
              }

              Box(
                modifier = Modifier
                  .background(PulseSurface, RoundedCornerShape(8.dp))
                  .border(1.dp, PulseBorder, RoundedCornerShape(8.dp))
                  .padding(horizontal = 10.dp, vertical = 4.dp)
              ) {
                Text(
                  text = "$percent%",
                  fontSize = 16.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (percent == 100) PulseAccent else PulsePrimary
                )
              }
            }

            Spacer(modifier = Modifier.height(12.dp))

            PulseProgressBar(
              progress = progress,
              height = 10.dp,
              modifier = Modifier.fillMaxWidth()
            )

            if (percent == 100 && total > 0) {
              Spacer(modifier = Modifier.height(8.dp))
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Default.Celebration,
                  contentDescription = null,
                  tint = PulseAccent,
                  modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "All habits completed! You're unstoppable today.",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Medium,
                  color = PulseInk
                )
              }
            }
          }
        }
      }

      // AI Coach Spotlight Card
      // Focus Studio Pomodoro Banner Card
      item {
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onNavigateToFocus() }
            .testTag("today_focus_timer_card"),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = PulseSurface),
          border = BorderStroke(1.dp, PulseBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(48.dp)
                  .clip(RoundedCornerShape(10.dp))
                  .background(PulseLightTeal),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = Icons.Default.Timer,
                  contentDescription = "Focus Timer",
                  tint = PulsePrimary,
                  modifier = Modifier.size(26.dp)
                )
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text(
                  text = "Focus Studio & Timer",
                  fontSize = 14.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = PulseInk
                )
                Text(
                  text = "Start a 25-min Pomodoro session to build your habit streak.",
                  fontSize = 12.sp,
                  color = PulseMuted,
                  lineHeight = 16.sp
                )
              }
            }

            Surface(
              shape = RoundedCornerShape(8.dp),
              color = PulseLightTeal
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = "Start",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = PulsePrimary
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                  imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                  contentDescription = null,
                  tint = PulsePrimary,
                  modifier = Modifier.size(14.dp)
                )
              }
            }
          }
        }
      }

      // Section: Habits Checklist
      item {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(top = 4.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Daily Checklist",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = PulseInk
          )

          Text(
            text = "$completed / $total",
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = PulseMuted
          )
        }
      }

      if (habits.isEmpty()) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = PulseSurface),
            border = BorderStroke(1.dp, PulseBorder)
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Icon(
                imageVector = Icons.Default.SelfImprovement,
                contentDescription = null,
                tint = PulseMuted,
                modifier = Modifier.size(44.dp)
              )
              Spacer(modifier = Modifier.height(10.dp))
              Text(
                text = "No habits tracked yet",
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
                color = PulseInk
              )
              Text(
                text = "Tap below or the '+' button to add your first daily habit.",
                fontSize = 13.sp,
                color = PulseMuted,
                modifier = Modifier.padding(top = 4.dp, bottom = 14.dp)
              )
              Button(
                onClick = onNavigateToAdd,
                colors = ButtonDefaults.buttonColors(
                  containerColor = PulseAccent,
                  contentColor = PulseOnAccent
                ),
                shape = RoundedCornerShape(8.dp)
              ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add Your First Habit")
              }
            }
          }
        }
      } else {
        items(habits, key = { it.id }) { habit ->
          HabitCard(
            habit = habit,
            onToggleComplete = { viewModel.toggleHabit(habit) }
          )
        }
      }
    }
  }
}
