package com.example.ui.navigation

/**
 * Type-safe navigation routes for PulseTrack.
 * Manages all primary screens: Today, Habits, AddHabit, Stats, Settings,
 * along with AI companion features Coach Pulse and Vision Studio.
 */
sealed class Screen(val route: String) {
  data object Today : Screen("today")
  data object Habits : Screen("habits")
  data object AddHabit : Screen("add")
  data object Stats : Screen("stats")
  data object Settings : Screen("settings")
  data object FocusTimer : Screen("focus")
  data object Coach : Screen("coach")
  data object Vision : Screen("vision")
  data object LiveVoice : Screen("voice")
}
