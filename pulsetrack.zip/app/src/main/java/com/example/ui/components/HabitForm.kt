package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.HabitEntity
import com.example.ui.theme.PulseAccent
import com.example.ui.theme.PulseBorder
import com.example.ui.theme.PulseDestructive
import com.example.ui.theme.PulseInk
import com.example.ui.theme.PulseLightTeal
import com.example.ui.theme.PulseMuted
import com.example.ui.theme.PulseOnAccent
import com.example.ui.theme.PulsePrimary
import com.example.ui.theme.PulseSoft
import com.example.ui.theme.PulseSurface
import kotlin.math.max

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HabitForm(
  initialHabit: HabitEntity? = null,
  onSubmit: (name: String, iconName: String, frequency: String, dailyGoal: Int) -> Unit,
  onCancel: () -> Unit,
  modifier: Modifier = Modifier
) {
  var name by remember { mutableStateOf(initialHabit?.name ?: "") }
  var selectedIcon by remember { mutableStateOf(initialHabit?.iconName ?: "water") }
  var selectedFrequency by remember { mutableStateOf(initialHabit?.frequency ?: "Daily") }
  var dailyGoal by remember { mutableIntStateOf(initialHabit?.dailyGoal ?: 1) }

  var nameError by remember { mutableStateOf<String?>(null) }
  var goalError by remember { mutableStateOf<String?>(null) }

  val frequencies = listOf("Daily", "3x/week", "5x/week", "Weekly", "Custom")

  fun validateAndSubmit() {
    var isValid = true

    if (name.trim().length < 2) {
      nameError = "Habit name must be at least 2 characters"
      isValid = false
    } else {
      nameError = null
    }

    if (dailyGoal < 1) {
      goalError = "Daily goal must be 1 or more"
      isValid = false
    } else {
      goalError = null
    }

    if (isValid) {
      onSubmit(name.trim(), selectedIcon, selectedFrequency, dailyGoal)
    }
  }

  Column(
    modifier = modifier
      .fillMaxWidth()
      .testTag("habit_form"),
    verticalArrangement = Arrangement.spacedBy(20.dp)
  ) {
    // 1. Habit Name
    PulseInputField(
      value = name,
      onValueChange = {
        name = it
        if (it.trim().length >= 2) nameError = null
      },
      label = "Habit Name",
      placeholder = "e.g. Drink water, Read 20 pages",
      helperText = "What habit do you want to build?",
      errorMessage = nameError,
      testTag = "habit_name_input"
    )

    // 2. Icon Picker
    Column {
      Text(
        text = "Select Icon",
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        color = PulseInk,
        modifier = Modifier.padding(bottom = 8.dp)
      )

      FlowRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        HabitIconRegistry.options.forEach { option ->
          val isSelected = selectedIcon.equals(option.id, ignoreCase = true)
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = if (isSelected) PulseLightTeal else PulseSurface,
            border = BorderStroke(
              width = if (isSelected) 1.5.dp else 1.dp,
              color = if (isSelected) PulsePrimary else PulseBorder
            ),
            modifier = Modifier
              .testTag("icon_picker_${option.id}")
              .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(),
                onClick = { selectedIcon = option.id }
              )
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = option.icon,
                contentDescription = option.label,
                tint = if (isSelected) PulsePrimary else PulseInk,
                modifier = Modifier.size(18.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = option.label,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                color = if (isSelected) PulsePrimary else PulseInk
              )
            }
          }
        }
      }
    }

    // 3. Frequency Picker
    Column {
      Text(
        text = "Frequency",
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        color = PulseInk,
        modifier = Modifier.padding(bottom = 8.dp)
      )

      FlowRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        frequencies.forEach { freq ->
          val isSelected = selectedFrequency == freq
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = if (isSelected) PulsePrimary else PulseSurface,
            border = BorderStroke(
              width = 1.dp,
              color = if (isSelected) PulsePrimary else PulseBorder
            ),
            modifier = Modifier
              .testTag("freq_chip_$freq")
              .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(),
                onClick = { selectedFrequency = freq }
              )
          ) {
            Text(
              text = freq,
              fontSize = 13.sp,
              fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
              color = if (isSelected) PulseOnAccent else PulseInk,
              modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
            )
          }
        }
      }
    }

    // 4. Daily Goal (Counter & Input)
    Column {
      Text(
        text = "Daily Goal",
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        color = PulseInk,
        modifier = Modifier.padding(bottom = 6.dp)
      )

      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Decrement button
        IconButton(
          onClick = { if (dailyGoal > 1) dailyGoal-- },
          modifier = Modifier
            .size(44.dp)
            .background(PulseSoft, RoundedCornerShape(8.dp))
            .border(1.dp, PulseBorder, RoundedCornerShape(8.dp))
            .testTag("decrement_goal_button")
        ) {
          Icon(Icons.Default.Remove, contentDescription = "Decrease", tint = PulseInk)
        }

        Spacer(modifier = Modifier.width(12.dp))

        // Center display / manual input
        Box(
          modifier = Modifier
            .weight(1f)
            .height(44.dp)
            .background(PulseSurface, RoundedCornerShape(10.dp))
            .border(1.dp, PulseBorder, RoundedCornerShape(10.dp)),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = "$dailyGoal time${if (dailyGoal > 1) "s" else ""} per day",
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            color = PulseInk,
            modifier = Modifier.testTag("daily_goal_display")
          )
        }

        Spacer(modifier = Modifier.width(12.dp))

        // Increment button
        IconButton(
          onClick = { dailyGoal++ },
          modifier = Modifier
            .size(44.dp)
            .background(PulseSoft, RoundedCornerShape(8.dp))
            .border(1.dp, PulseBorder, RoundedCornerShape(8.dp))
            .testTag("increment_goal_button")
        ) {
          Icon(Icons.Default.Add, contentDescription = "Increase", tint = PulseInk)
        }
      }

      if (goalError != null) {
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = goalError!!, fontSize = 12.sp, color = PulseDestructive)
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Form Action Buttons
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      OutlinedButton(
        onClick = onCancel,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, PulseBorder),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = PulseInk),
        modifier = Modifier
          .weight(1f)
          .height(48.dp)
          .testTag("cancel_habit_button")
      ) {
        Text("Cancel", fontWeight = FontWeight.Medium)
      }

      Button(
        onClick = { validateAndSubmit() },
        shape = RoundedCornerShape(10.dp),
        colors = ButtonDefaults.buttonColors(
          containerColor = PulseAccent,
          contentColor = PulseOnAccent
        ),
        modifier = Modifier
          .weight(1.5f)
          .height(48.dp)
          .testTag("submit_habit_button")
      ) {
        Text(
          text = if (initialHabit == null) "Create Habit" else "Save Changes",
          fontSize = 15.sp,
          fontWeight = FontWeight.SemiBold
        )
      }
    }
  }
}
