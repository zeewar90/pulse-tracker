package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.HabitEntity
import com.example.ui.HabitViewModel
import com.example.ui.components.PulseTabBar
import com.example.ui.components.TabDestination
import com.example.ui.navigation.Screen
import com.example.ui.pages.AddHabitScreen
import com.example.ui.pages.FocusTimerScreen
import com.example.ui.pages.HabitsScreen
import com.example.ui.pages.SettingsScreen
import com.example.ui.pages.StatsScreen
import com.example.ui.pages.TodayScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.PulseBg
import com.example.ui.theme.PulseSoft

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        PulseTrackApp()
      }
    }
  }
}

@Composable
fun PulseTrackApp() {
  val navController = rememberNavController()
  val habitViewModel: HabitViewModel = viewModel()
  val habits by habitViewModel.allHabits.collectAsState()

  val navBackStackEntry by navController.currentBackStackEntryAsState()
  val currentRoute = navBackStackEntry?.destination?.route ?: Screen.Today.route

  var habitToEdit by remember { mutableStateOf<HabitEntity?>(null) }

  val isTopLevelDestination = currentRoute in listOf(
    Screen.Today.route,
    Screen.Habits.route,
    Screen.Stats.route,
    Screen.Settings.route
  )

  // 430px centered mobile container for clean responsive layout
  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(PulseSoft),
    contentAlignment = Alignment.Center
  ) {
    Box(
      modifier = Modifier
        .fillMaxHeight()
        .widthIn(max = 430.dp)
        .fillMaxWidth()
        .background(PulseBg)
    ) {
      Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        containerColor = PulseBg,
        bottomBar = {
          if (isTopLevelDestination) {
            PulseTabBar(
              currentRoute = currentRoute,
              onNavigate = { route ->
                if (currentRoute != route) {
                  navController.navigate(route) {
                    popUpTo(Screen.Today.route) {
                      saveState = true
                    }
                    launchSingleTop = true
                    restoreState = true
                  }
                }
              },
              onAddClick = {
                habitToEdit = null
                navController.navigate(Screen.AddHabit.route)
              }
            )
          }
        }
      ) { innerPadding ->
        NavHost(
          navController = navController,
          startDestination = Screen.Today.route,
          modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
        ) {
          composable(Screen.Today.route) {
            TodayScreen(
              habits = habits,
              viewModel = habitViewModel,
              onNavigateToAdd = {
                habitToEdit = null
                navController.navigate(Screen.AddHabit.route)
              },
              onNavigateToFocus = {
                navController.navigate(Screen.FocusTimer.route)
              },
              onNavigateToHabits = {
                navController.navigate(Screen.Habits.route)
              },
              onNavigateToSettings = {
                navController.navigate(Screen.Settings.route)
              }
            )
          }

          composable(Screen.Habits.route) {
            HabitsScreen(
              habits = habits,
              viewModel = habitViewModel,
              onNavigateToAdd = {
                habitToEdit = null
                navController.navigate(Screen.AddHabit.route)
              },
              onEditHabit = { habit ->
                habitToEdit = habit
                navController.navigate(Screen.AddHabit.route)
              }
            )
          }

          composable(Screen.AddHabit.route) {
            AddHabitScreen(
              viewModel = habitViewModel,
              habitToEdit = habitToEdit,
              onNavigateBack = {
                navController.popBackStack()
              }
            )
          }

          composable(Screen.Stats.route) {
            StatsScreen(
              habits = habits,
              viewModel = habitViewModel
            )
          }

          composable(Screen.Settings.route) {
            SettingsScreen(
              viewModel = habitViewModel,
              onSignOut = {
                navController.navigate(Screen.Today.route) {
                  popUpTo(Screen.Today.route) { inclusive = true }
                }
              }
            )
          }

          composable(Screen.FocusTimer.route) {
            FocusTimerScreen(
              viewModel = habitViewModel,
              onNavigateBack = {
                navController.popBackStack()
              }
            )
          }

          // Legacy routes fallback to FocusTimerScreen
          composable(Screen.Coach.route) {
            FocusTimerScreen(
              viewModel = habitViewModel,
              onNavigateBack = {
                navController.popBackStack()
              }
            )
          }

          composable(Screen.Vision.route) {
            FocusTimerScreen(
              viewModel = habitViewModel,
              onNavigateBack = {
                navController.popBackStack()
              }
            )
          }

          composable(Screen.LiveVoice.route) {
            FocusTimerScreen(
              viewModel = habitViewModel,
              onNavigateBack = {
                navController.popBackStack()
              }
            )
          }
        }
      }
    }
  }
}
