package com.example.data

object SampleHabits {
  val initialHabits = listOf(
    HabitEntity(
      id = 1,
      name = "Drink water",
      iconName = "water",
      frequency = "Daily",
      dailyGoal = 8,
      streak = 14,
      completedToday = true,
      weeklyHistory = "1,1,1,1,1,1,1",
      bestStreak = 21
    ),
    HabitEntity(
      id = 2,
      name = "Morning stretch",
      iconName = "stretch",
      frequency = "Daily",
      dailyGoal = 1,
      streak = 7,
      completedToday = true,
      weeklyHistory = "1,1,1,0,1,1,1",
      bestStreak = 12
    ),
    HabitEntity(
      id = 3,
      name = "Read 20 pages",
      iconName = "book",
      frequency = "Daily",
      dailyGoal = 20,
      streak = 5,
      completedToday = false,
      weeklyHistory = "1,0,1,1,1,1,0",
      bestStreak = 9
    ),
    HabitEntity(
      id = 4,
      name = "Mindful meditation",
      iconName = "meditation",
      frequency = "Daily",
      dailyGoal = 1,
      streak = 12,
      completedToday = false,
      weeklyHistory = "1,1,1,1,0,1,0",
      bestStreak = 15
    ),
    HabitEntity(
      id = 5,
      name = "Evening walk",
      iconName = "walk",
      frequency = "5x/week",
      dailyGoal = 1,
      streak = 3,
      completedToday = false,
      weeklyHistory = "0,1,1,0,1,0,0",
      bestStreak = 8
    )
  )
}
