package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emptyFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

class HabitRepository(
  private val habitDao: HabitDao,
  private val habitCompletionDao: HabitCompletionDao? = null,
  private val streakDao: StreakDao? = null
) {
  val allHabits: Flow<List<Habit>> = habitDao.getAllHabits()
  val allCompletions: Flow<List<HabitCompletion>> = habitCompletionDao?.getAllCompletions() ?: emptyFlow()
  val allStreaks: Flow<List<Streak>> = streakDao?.getAllStreaks() ?: emptyFlow()

  private fun getTodayDateString(): String {
    return SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
  }

  suspend fun ensureInitialData() {
    val count = habitDao.getHabitCount()
    if (count == 0) {
      val habits = SampleHabits.initialHabits
      habitDao.insertAll(habits)

      val todayStr = getTodayDateString()
      streakDao?.insertAll(
        habits.map {
          Streak(
            habitId = it.id,
            currentStreak = it.streak,
            bestStreak = it.bestStreak,
            lastCompletedDate = if (it.completedToday) todayStr else null,
            startDate = todayStr
          )
        }
      )

      habitCompletionDao?.insertAll(
        habits.filter { it.completedToday }.map {
          HabitCompletion(
            habitId = it.id,
            completionDate = todayStr,
            count = it.dailyGoal
          )
        }
      )
    }
  }

  suspend fun toggleHabitCompletion(habit: Habit): Habit {
    val newCompleted = !habit.completedToday
    val newStreak = if (newCompleted) {
      habit.streak + 1
    } else {
      max(0, habit.streak - 1)
    }
    val newBestStreak = max(habit.bestStreak, newStreak)
    val todayStr = getTodayDateString()

    // Update weekly history: 7 days, index 6 represents today
    val historyList = habit.weeklyHistory.split(",").toMutableList()
    while (historyList.size < 7) {
      historyList.add(0, "0")
    }
    if (historyList.size > 7) {
      val trimmed = historyList.takeLast(7).toMutableList()
      historyList.clear()
      historyList.addAll(trimmed)
    }
    historyList[6] = if (newCompleted) "1" else "0"
    val updatedWeekly = historyList.joinToString(",")

    val updatedHabit = habit.copy(
      completedToday = newCompleted,
      streak = newStreak,
      bestStreak = newBestStreak,
      weeklyHistory = updatedWeekly
    )
    habitDao.updateHabit(updatedHabit)

    // Sync to HabitCompletion entity table
    if (habitCompletionDao != null) {
      if (newCompleted) {
        habitCompletionDao.insertCompletion(
          HabitCompletion(
            habitId = habit.id,
            completionDate = todayStr,
            completedAtTimestamp = System.currentTimeMillis(),
            count = habit.dailyGoal
          )
        )
      } else {
        habitCompletionDao.deleteCompletionForDate(habit.id, todayStr)
      }
    }

    // Sync to Streak entity table
    if (streakDao != null) {
      val existingStreak = streakDao.getStreakForHabitSync(habit.id)
      if (existingStreak != null) {
        streakDao.updateStreakProgress(
          habitId = habit.id,
          currentStreak = newStreak,
          bestStreak = newBestStreak,
          lastDate = if (newCompleted) todayStr else existingStreak.lastCompletedDate ?: "",
          timestamp = System.currentTimeMillis()
        )
      } else {
        streakDao.insertStreak(
          Streak(
            habitId = habit.id,
            currentStreak = newStreak,
            bestStreak = newBestStreak,
            lastCompletedDate = if (newCompleted) todayStr else null,
            startDate = todayStr
          )
        )
      }
    }

    return updatedHabit
  }

  suspend fun insert(habit: Habit): Long {
    val id = habitDao.insertHabit(habit)
    val habitId = if (habit.id != 0) habit.id else id.toInt()
    val todayStr = getTodayDateString()

    streakDao?.insertStreak(
      Streak(
        habitId = habitId,
        currentStreak = habit.streak,
        bestStreak = habit.bestStreak,
        lastCompletedDate = if (habit.completedToday) todayStr else null,
        startDate = todayStr
      )
    )

    if (habit.completedToday) {
      habitCompletionDao?.insertCompletion(
        HabitCompletion(
          habitId = habitId,
          completionDate = todayStr,
          count = habit.dailyGoal
        )
      )
    }

    return id
  }

  suspend fun update(habit: Habit) {
    habitDao.updateHabit(habit)
  }

  suspend fun delete(habit: Habit) {
    habitDao.deleteHabit(habit)
    habitCompletionDao?.deleteAllForHabit(habit.id)
    streakDao?.deleteStreakForHabit(habit.id)
  }

  suspend fun deleteById(id: Int) {
    habitDao.deleteHabitById(id)
    habitCompletionDao?.deleteAllForHabit(id)
    streakDao?.deleteStreakForHabit(id)
  }

  suspend fun resetToDefault() {
    habitDao.clearAll()
    habitCompletionDao?.clearAll()
    streakDao?.clearAll()
    ensureInitialData()
  }

  fun getCompletionsForHabit(habitId: Int): Flow<List<HabitCompletion>> {
    return habitCompletionDao?.getCompletionsForHabit(habitId) ?: emptyFlow()
  }

  fun getStreakForHabit(habitId: Int): Flow<Streak?> {
    return streakDao?.getStreakForHabit(habitId) ?: emptyFlow()
  }
}
