package com.example.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Room Entity representing a single completion record of a habit on a specific date.
 */
@Entity(
  tableName = "habit_completions",
  foreignKeys = [
    ForeignKey(
      entity = Habit::class,
      parentColumns = ["id"],
      childColumns = ["habitId"],
      onDelete = ForeignKey.CASCADE
    )
  ],
  indices = [
    Index(value = ["habitId"]),
    Index(value = ["completionDate"]),
    Index(value = ["habitId", "completionDate"], unique = true)
  ]
)
data class HabitCompletion(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  @ColumnInfo(name = "habitId")
  val habitId: Int,
  @ColumnInfo(name = "completionDate")
  val completionDate: String, // Date in "yyyy-MM-dd" format
  @ColumnInfo(name = "completedAtTimestamp")
  val completedAtTimestamp: Long = System.currentTimeMillis(),
  @ColumnInfo(name = "count")
  val count: Int = 1,
  @ColumnInfo(name = "notes")
  val notes: String = ""
)
