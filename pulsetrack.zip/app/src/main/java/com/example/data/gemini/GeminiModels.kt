package com.example.data.gemini

enum class CoachRole(
  val title: String,
  val subtitle: String,
  val modelId: String,
  val speedLabel: String,
  val systemInstruction: String
) {
  DAILY_COACH(
    title = "Habit Coach",
    subtitle = "Daily motivation & routine guidance",
    modelId = "gemini-3.5-flash",
    speedLabel = "Standard",
    systemInstruction = """
      You are the Daily Habit Coach for PulseTrack, a mindful habit tracker app.
      Your tone is warm, encouraging, practical, and grounded in behavioral science.
      Help users build sustainable routines, celebrate daily progress, troubleshoot missed habits without guilt,
      and provide actionable, bite-sized advice. Format your answers clearly with bullet points where helpful.
    """.trimIndent()
  ),

  DEEP_STRATEGIST(
    title = "Deep Strategist",
    subtitle = "Root-cause analysis & habit architecture",
    modelId = "gemini-3.1-pro-preview",
    speedLabel = "Deep Reasoning",
    systemInstruction = """
      You are the Deep Habit Strategist for PulseTrack, an advanced behavioral scientist and cognitive architect.
      You specialize in high-complexity habit formation, tackling chronic procrastination, breaking deeply ingrained negative cycles,
      reframing cognitive distortions, environmental design, and long-term momentum systems.
      Provide structured, deeply reasoned, and evidence-based analysis for complex challenges.
    """.trimIndent()
  ),

  QUICK_PEPTALK(
    title = "Quick Pep-Talk",
    subtitle = "Rapid check-in & instant energy",
    modelId = "gemini-3.1-flash-lite",
    speedLabel = "Lightning Fast",
    systemInstruction = """
      You are the Quick Habit Sparring Partner for PulseTrack.
      Deliver fast, punchy, high-energy bursts of inspiration and immediate micro-action steps.
      Keep your answers brief (2 to 4 concise sentences). Get straight to the point and spark immediate action!
    """.trimIndent()
  )
}

data class ChatMessage(
  val id: String = java.util.UUID.randomUUID().toString(),
  val role: String, // "user" or "model"
  val text: String,
  val timestamp: Long = System.currentTimeMillis(),
  val modelUsed: String? = null
)

data class VisionImageItem(
  val id: String = java.util.UUID.randomUUID().toString(),
  val prompt: String,
  val base64Data: String,
  val aspectRatio: String = "1:1",
  val timestamp: Long = System.currentTimeMillis(),
  val isEdited: Boolean = false,
  val originalPrompt: String? = null,
  val description: String? = null
)

enum class LiveSessionState {
  DISCONNECTED,
  CONNECTING,
  CONNECTED,
  LISTENING,
  THINKING,
  SPEAKING,
  ERROR
}

data class LiveVoicePersona(
  val voiceName: String,
  val displayName: String,
  val description: String
)

data class LiveTranscriptItem(
  val id: String = java.util.UUID.randomUUID().toString(),
  val isUser: Boolean,
  val text: String,
  val timestamp: Long = System.currentTimeMillis()
)

