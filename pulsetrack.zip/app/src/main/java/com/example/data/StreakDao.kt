package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for streaks table.
 */
@Dao
interface StreakDao {
  @Query("SELECT * FROM streaks ORDER BY currentStreak DESC")
  fun getAllStreaks(): Flow<List<Streak>>

  @Query("SELECT * FROM streaks WHERE habitId = :habitId LIMIT 1")
  fun getStreakForHabit(habitId: Int): Flow<Streak?>

  @Query("SELECT * FROM streaks WHERE habitId = :habitId LIMIT 1")
  suspend fun getStreakForHabitSync(habitId: Int): Streak?

  @Query("SELECT * FROM streaks ORDER BY bestStreak DESC LIMIT :limit")
  fun getTopStreaks(limit: Int = 5): Flow<List<Streak>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertStreak(streak: Streak): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(streaks: List<Streak>)

  @Update
  suspend fun updateStreak(streak: Streak)

  @Query("UPDATE streaks SET currentStreak = :currentStreak, bestStreak = :bestStreak, lastCompletedDate = :lastDate, lastUpdatedTimestamp = :timestamp WHERE habitId = :habitId")
  suspend fun updateStreakProgress(
    habitId: Int,
    currentStreak: Int,
    bestStreak: Int,
    lastDate: String,
    timestamp: Long
  )

  @Delete
  suspend fun deleteStreak(streak: Streak)

  @Query("DELETE FROM streaks WHERE habitId = :habitId")
  suspend fun deleteStreakForHabit(habitId: Int)

  @Query("DELETE FROM streaks")
  suspend fun clearAll()
}
