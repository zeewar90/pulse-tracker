package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for habit_completions table.
 */
@Dao
interface HabitCompletionDao {
  @Query("SELECT * FROM habit_completions ORDER BY completedAtTimestamp DESC")
  fun getAllCompletions(): Flow<List<HabitCompletion>>

  @Query("SELECT * FROM habit_completions WHERE habitId = :habitId ORDER BY completedAtTimestamp DESC")
  fun getCompletionsForHabit(habitId: Int): Flow<List<HabitCompletion>>

  @Query("SELECT * FROM habit_completions WHERE habitId = :habitId AND completionDate = :date LIMIT 1")
  suspend fun getCompletionForHabitAndDate(habitId: Int, date: String): HabitCompletion?

  @Query("SELECT * FROM habit_completions WHERE completionDate = :date ORDER BY completedAtTimestamp DESC")
  fun getCompletionsForDate(date: String): Flow<List<HabitCompletion>>

  @Query("SELECT COUNT(*) FROM habit_completions WHERE habitId = :habitId")
  suspend fun getCompletionCountForHabit(habitId: Int): Int

  @Query("SELECT COUNT(*) FROM habit_completions WHERE completionDate = :date")
  suspend fun getCompletionCountForDate(date: String): Int

  @Query("SELECT COUNT(*) FROM habit_completions")
  suspend fun getTotalCompletionsCount(): Int

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertCompletion(completion: HabitCompletion): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(completions: List<HabitCompletion>)

  @Update
  suspend fun updateCompletion(completion: HabitCompletion)

  @Delete
  suspend fun deleteCompletion(completion: HabitCompletion)

  @Query("DELETE FROM habit_completions WHERE habitId = :habitId AND completionDate = :date")
  suspend fun deleteCompletionForDate(habitId: Int, date: String)

  @Query("DELETE FROM habit_completions WHERE habitId = :habitId")
  suspend fun deleteAllForHabit(habitId: Int)

  @Query("DELETE FROM habit_completions")
  suspend fun clearAll()
}
