package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Room Database for PulseTrack containing Habit, HabitCompletion, and Streak entities.
 */
@Database(
  entities = [
    Habit::class,
    HabitCompletion::class,
    Streak::class
  ],
  version = 2,
  exportSchema = false
)
abstract class PulseTrackDatabase : RoomDatabase() {
  abstract fun habitDao(): HabitDao
  abstract fun habitCompletionDao(): HabitCompletionDao
  abstract fun streakDao(): StreakDao

  companion object {
    @Volatile
    private var INSTANCE: PulseTrackDatabase? = null

    fun getDatabase(context: Context, scope: CoroutineScope): PulseTrackDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          PulseTrackDatabase::class.java,
          "pulsetrack_database"
        )
          .fallbackToDestructiveMigration(true)
          .addCallback(PulseTrackDatabaseCallback(scope))
          .build()
        INSTANCE = instance
        instance
      }
    }
  }

  private class PulseTrackDatabaseCallback(
    private val scope: CoroutineScope
  ) : RoomDatabase.Callback() {
    override fun onCreate(db: SupportSQLiteDatabase) {
      super.onCreate(db)
      INSTANCE?.let { database ->
        scope.launch(Dispatchers.IO) {
          populateInitialDatabase(database)
        }
      }
    }

    private suspend fun populateInitialDatabase(database: PulseTrackDatabase) {
      val habits = SampleHabits.initialHabits
      database.habitDao().insertAll(habits)

      val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

      // Populate corresponding streaks
      val initialStreaks = habits.map { habit ->
        Streak(
          habitId = habit.id,
          currentStreak = habit.streak,
          bestStreak = habit.bestStreak,
          lastCompletedDate = if (habit.completedToday) todayStr else null,
          startDate = todayStr
        )
      }
      database.streakDao().insertAll(initialStreaks)

      // Populate initial completions for completed habits
      val initialCompletions = habits.filter { it.completedToday }.map { habit ->
        HabitCompletion(
          habitId = habit.id,
          completionDate = todayStr,
          completedAtTimestamp = System.currentTimeMillis(),
          count = habit.dailyGoal
        )
      }
      database.habitCompletionDao().insertAll(initialCompletions)
    }
  }
}

/**
 * Standard AppDatabase alias for standardized RoomDatabase naming.
 */
typealias AppDatabase = PulseTrackDatabase
