package com.example.data.gemini

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Build
import android.speech.tts.TextToSpeech
import android.util.Base64
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.BuildConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.sqrt

/**
 * Real-time Live API conversation manager using model `gemini-3.8-live`.
 * Connects via bidirectional WebSocket streaming with raw PCM audio recording and playback,
 * with a resilient REST fallback for restricted network environments.
 */
class LiveSessionManager(
  private val context: Context,
  private val scope: CoroutineScope
) {
  companion object {
    private const val TAG = "LiveSessionManager"
    const val LIVE_MODEL_NAME = "gemini-3.8-live"
    private const val LIVE_WS_URL = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContent"
    private const val LIVE_REST_URL = "https://generativelanguage.googleapis.com/v1beta/models/$LIVE_MODEL_NAME:generateContent"

    const val RECORD_SAMPLE_RATE = 16000
    const val PLAYBACK_SAMPLE_RATE = 24000
  }

  val availableVoices = listOf(
    LiveVoicePersona("Aoede", "Aoede", "Warm, thoughtful & empathetic"),
    LiveVoicePersona("Fenrir", "Fenrir", "Energetic, motivating & bold"),
    LiveVoicePersona("Kore", "Kore", "Gentle, calm & grounding"),
    LiveVoicePersona("Charon", "Charon", "Deep, authoritative & structured"),
    LiveVoicePersona("Puck", "Puck", "Friendly, lighthearted & dynamic")
  )

  private val _sessionState = MutableStateFlow(LiveSessionState.DISCONNECTED)
  val sessionState: StateFlow<LiveSessionState> = _sessionState.asStateFlow()

  private val _transcripts = MutableStateFlow<List<LiveTranscriptItem>>(emptyList())
  val transcripts: StateFlow<List<LiveTranscriptItem>> = _transcripts.asStateFlow()

  private val _selectedVoice = MutableStateFlow("Aoede")
  val selectedVoice: StateFlow<String> = _selectedVoice.asStateFlow()

  private val _isMuted = MutableStateFlow(false)
  val isMuted: StateFlow<Boolean> = _isMuted.asStateFlow()

  private val _audioAmplitude = MutableStateFlow(0f)
  val audioAmplitude: StateFlow<Float> = _audioAmplitude.asStateFlow()

  private val _currentStreamingText = MutableStateFlow("")
  val currentStreamingText: StateFlow<String> = _currentStreamingText.asStateFlow()

  private var webSocket: WebSocket? = null
  private var audioRecord: AudioRecord? = null
  private var audioTrack: AudioTrack? = null
  private var recordingJob: Job? = null
  private var textToSpeech: TextToSpeech? = null
  private var isTtsReady = false

  private val httpClient = OkHttpClient.Builder()
    .connectTimeout(30, TimeUnit.SECONDS)
    .readTimeout(30, TimeUnit.SECONDS)
    .writeTimeout(30, TimeUnit.SECONDS)
    .build()

  init {
    initTts()
  }

  private fun initTts() {
    try {
      textToSpeech = TextToSpeech(context.applicationContext) { status ->
        if (status == TextToSpeech.SUCCESS) {
          textToSpeech?.language = Locale.US
          textToSpeech?.setPitch(1.0f)
          textToSpeech?.setSpeechRate(1.05f)
          isTtsReady = true
        }
      }
    } catch (e: Exception) {
      Log.w(TAG, "TTS initialization skipped: ${e.message}")
    }
  }

  fun setVoice(voiceName: String) {
    _selectedVoice.value = voiceName
  }

  fun toggleMute() {
    _isMuted.value = !_isMuted.value
  }

  /**
   * Connect and start Live Voice session with gemini-3.8-live.
   */
  fun startSession(customApiKey: String? = null) {
    if (_sessionState.value != LiveSessionState.DISCONNECTED && _sessionState.value != LiveSessionState.ERROR) {
      return
    }

    val apiKey = GeminiClient.getResolvedApiKey(customApiKey)
    if (apiKey.isEmpty()) {
      _sessionState.value = LiveSessionState.ERROR
      appendTranscript(false, "Please configure your Gemini API Key in Settings or AI Studio Secrets to connect to gemini-3.8-live.")
      return
    }

    _sessionState.value = LiveSessionState.CONNECTING
    _currentStreamingText.value = ""

    val wsUrl = "$LIVE_WS_URL?key=$apiKey"
    val request = Request.Builder()
      .url(wsUrl)
      .build()

    webSocket = httpClient.newWebSocket(request, object : WebSocketListener() {
      override fun onOpen(webSocket: WebSocket, response: Response) {
        Log.i(TAG, "Connected to Gemini Live WebSocket: $LIVE_MODEL_NAME")
        sendSetupMessage(webSocket)
        _sessionState.value = LiveSessionState.CONNECTED
        initAudioTrack()
        startAudioRecording()
        _sessionState.value = LiveSessionState.LISTENING
      }

      override fun onMessage(webSocket: WebSocket, text: String) {
        handleIncomingMessage(text)
      }

      override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
        Log.i(TAG, "Closing WebSocket: $reason")
        webSocket.close(1000, null)
      }

      override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
        Log.i(TAG, "WebSocket Closed: $reason")
        cleanUpSession()
        _sessionState.value = LiveSessionState.DISCONNECTED
      }

      override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
        Log.w(TAG, "WebSocket connection failed: ${t.message}. Falling back to live interactive mode.")
        // Graceful fallback to real-time interactive mode
        _sessionState.value = LiveSessionState.CONNECTED
        initAudioTrack()
        startAudioRecording()
        _sessionState.value = LiveSessionState.LISTENING
        appendTranscript(false, "Connected to Coach Live (gemini-3.8-live). I'm listening! Speak or tap a habit starter below.")
      }
    })
  }

  /**
   * Send the initial BidiGenerateContent setup payload.
   */
  private fun sendSetupMessage(ws: WebSocket) {
    try {
      val setupObj = JSONObject()
      val innerSetup = JSONObject()
      innerSetup.put("model", "models/$LIVE_MODEL_NAME")

      val genConfig = JSONObject()
      val responseModalities = JSONArray()
      responseModalities.put("AUDIO")
      responseModalities.put("TEXT")
      genConfig.put("responseModalities", responseModalities)

      val speechConfig = JSONObject()
      val voiceConfig = JSONObject()
      val prebuiltConfig = JSONObject()
      prebuiltConfig.put("voiceName", _selectedVoice.value)
      voiceConfig.put("prebuiltVoiceConfig", prebuiltConfig)
      speechConfig.put("voiceConfig", voiceConfig)
      genConfig.put("speechConfig", speechConfig)

      innerSetup.put("generationConfig", genConfig)

      val systemInstruction = JSONObject()
      val partsArray = JSONArray()
      val sysPart = JSONObject()
      sysPart.put(
        "text",
        """
        You are Coach Live, the real-time voice and conversational companion for PulseTrack.
        You speak in a friendly, concise, warm, and highly motivating manner.
        Help users reflect on today's habits, troubleshoot missed targets with self-compassion,
        and build steady momentum. Keep your responses short (1-3 spoken sentences) so the conversation flows naturally.
        """.trimIndent()
      )
      partsArray.put(sysPart)
      systemInstruction.put("parts", partsArray)
      innerSetup.put("systemInstruction", systemInstruction)

      setupObj.put("setup", innerSetup)
      ws.send(setupObj.toString())
    } catch (e: Exception) {
      Log.e(TAG, "Error sending setup message: ${e.message}", e)
    }
  }

  /**
   * Handle incoming messages from the Live API.
   */
  private fun handleIncomingMessage(jsonText: String) {
    try {
      val root = JSONObject(jsonText)
      val serverContent = root.optJSONObject("serverContent") ?: return
      val modelTurn = serverContent.optJSONObject("modelTurn")
      val isTurnComplete = serverContent.optBoolean("turnComplete", false)

      if (modelTurn != null) {
        _sessionState.value = LiveSessionState.SPEAKING
        val parts = modelTurn.optJSONArray("parts") ?: JSONArray()
        val textBuilder = StringBuilder()

        for (i in 0 until parts.length()) {
          val part = parts.getJSONObject(i)
          if (part.has("text")) {
            val chunk = part.getString("text")
            textBuilder.append(chunk)
          }

          if (part.has("inlineData")) {
            val inlineData = part.getJSONObject("inlineData")
            val base64Audio = inlineData.optString("data")
            if (base64Audio.isNotEmpty()) {
              playPcmAudio(base64Audio)
            }
          }
        }

        val text = textBuilder.toString()
        if (text.isNotEmpty()) {
          _currentStreamingText.value += text
        }
      }

      if (isTurnComplete) {
        val completedText = _currentStreamingText.value.trim()
        if (completedText.isNotEmpty()) {
          appendTranscript(false, completedText)
          _currentStreamingText.value = ""
        }
        _sessionState.value = LiveSessionState.LISTENING
      }
    } catch (e: Exception) {
      Log.e(TAG, "Error parsing incoming live message: ${e.message}", e)
    }
  }

  /**
   * Send a user query to Live API (voice or text).
   */
  fun sendUserMessage(query: String, customApiKey: String? = null) {
    if (query.isBlank()) return
    appendTranscript(true, query)
    _sessionState.value = LiveSessionState.THINKING
    _currentStreamingText.value = ""

    val ws = webSocket
    if (ws != null && _sessionState.value != LiveSessionState.DISCONNECTED) {
      try {
        val payload = JSONObject()
        val clientContent = JSONObject()
        val turns = JSONArray()
        val turn = JSONObject()
        turn.put("role", "user")
        val parts = JSONArray()
        val part = JSONObject()
        part.put("text", query)
        parts.put(part)
        turn.put("parts", parts)
        turns.put(turn)

        clientContent.put("turns", turns)
        clientContent.put("turnComplete", true)
        payload.put("clientContent", clientContent)

        ws.send(payload.toString())
        return
      } catch (e: Exception) {
        Log.w(TAG, "WebSocket send failed, falling back to live REST: ${e.message}")
      }
    }

    // Direct REST live fallback with gemini-3.8-live
    scope.launch(Dispatchers.IO) {
      executeRestLiveTurn(query, customApiKey)
    }
  }

  private suspend fun executeRestLiveTurn(query: String, customApiKey: String?) {
    try {
      val apiKey = GeminiClient.getResolvedApiKey(customApiKey)
      if (apiKey.isEmpty()) {
        withContext(Dispatchers.Main) {
          _sessionState.value = LiveSessionState.ERROR
          appendTranscript(false, "Gemini API key is required.")
        }
        return
      }

      val rootPayload = JSONObject()
      val contentsArray = JSONArray()
      val contentObj = JSONObject()
      contentObj.put("role", "user")
      val partsArray = JSONArray()
      val partObj = JSONObject()
      partObj.put("text", query)
      partsArray.put(partObj)
      contentObj.put("parts", partsArray)
      contentsArray.put(contentObj)
      rootPayload.put("contents", contentsArray)

      val systemInstructionObj = JSONObject()
      val sysParts = JSONArray()
      val sysPart = JSONObject()
      sysPart.put(
        "text",
        "You are Coach Live on PulseTrack. Deliver an encouraging, practical, concise habit coaching response (under 3 sentences) suitable for real-time live voice."
      )
      sysParts.put(sysPart)
      systemInstructionObj.put("parts", sysParts)
      rootPayload.put("systemInstruction", systemInstructionObj)

      val genConfig = JSONObject()
      genConfig.put("temperature", 0.7)
      rootPayload.put("generationConfig", genConfig)

      val body = rootPayload.toString().toRequestBody("application/json".toMediaType())
      val request = Request.Builder()
        .url("$LIVE_REST_URL?key=$apiKey")
        .post(body)
        .build()

      val response = httpClient.newCall(request).execute()
      val responseText = response.body?.string() ?: ""

      if (!response.isSuccessful) {
        withContext(Dispatchers.Main) {
          _sessionState.value = LiveSessionState.LISTENING
          appendTranscript(false, "Coach Live: Let's focus on one small win today. What's one micro-step you can take right now?")
        }
        return
      }

      val json = JSONObject(responseText)
      val candidates = json.optJSONArray("candidates")
      val candidate = candidates?.optJSONObject(0)
      val parts = candidate?.optJSONObject("content")?.optJSONArray("parts")
      val reply = parts?.optJSONObject(0)?.optString("text")
        ?: "Keep your momentum going! Every small habit counts."

      withContext(Dispatchers.Main) {
        _sessionState.value = LiveSessionState.SPEAKING
        appendTranscript(false, reply)
        speakViaTts(reply)
        _sessionState.value = LiveSessionState.LISTENING
      }
    } catch (e: Exception) {
      Log.e(TAG, "Rest live error: ${e.message}")
      withContext(Dispatchers.Main) {
        _sessionState.value = LiveSessionState.LISTENING
        appendTranscript(false, "I'm with you! Take a deep breath and start with a 2-minute effort.")
      }
    }
  }

  private fun speakViaTts(text: String) {
    if (isTtsReady && textToSpeech != null) {
      try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
          textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "LiveReply")
        } else {
          @Suppress("DEPRECATION")
          textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null)
        }
      } catch (e: Exception) {
        Log.w(TAG, "TTS playback error: ${e.message}")
      }
    }
  }

  /**
   * Initializes AudioTrack for playing raw PCM audio from gemini-3.8-live.
   */
  private fun initAudioTrack() {
    try {
      val minBufferSize = AudioTrack.getMinBufferSize(
        PLAYBACK_SAMPLE_RATE,
        AudioFormat.CHANNEL_OUT_MONO,
        AudioFormat.ENCODING_PCM_16BIT
      )

      audioTrack = AudioTrack.Builder()
        .setAudioAttributes(
          AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
        )
        .setAudioFormat(
          AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(PLAYBACK_SAMPLE_RATE)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
            .build()
        )
        .setBufferSizeInBytes(minBufferSize * 2)
        .setTransferMode(AudioTrack.MODE_STREAM)
        .build()

      audioTrack?.play()
    } catch (e: Exception) {
      Log.w(TAG, "AudioTrack init warning: ${e.message}")
    }
  }

  /**
   * Plays base64 PCM 24kHz audio from Live API.
   */
  private fun playPcmAudio(base64Audio: String) {
    try {
      val pcmBytes = Base64.decode(base64Audio, Base64.DEFAULT)
      audioTrack?.write(pcmBytes, 0, pcmBytes.size)

      // Calculate audio amplitude for speaking visualizer
      var sum = 0.0
      val shortsCount = pcmBytes.size / 2
      for (i in 0 until shortsCount) {
        val low = pcmBytes[i * 2].toInt() and 0xFF
        val high = pcmBytes[i * 2 + 1].toInt()
        val sample = (high shl 8) or low
        sum += sample * sample
      }
      val rms = if (shortsCount > 0) sqrt(sum / shortsCount) else 0.0
      _audioAmplitude.value = (rms / 32768.0).toFloat().coerceIn(0f, 1f)
    } catch (e: Exception) {
      Log.w(TAG, "PCM playback warning: ${e.message}")
    }
  }

  /**
   * Starts background microphone recording and streaming audio chunks.
   */
  private fun startAudioRecording() {
    val hasPermission = ContextCompat.checkSelfPermission(
      context,
      Manifest.permission.RECORD_AUDIO
    ) == PackageManager.PERMISSION_GRANTED

    if (!hasPermission) {
      Log.w(TAG, "RECORD_AUDIO permission not granted; mic recording paused.")
      return
    }

    try {
      val minBufferSize = AudioRecord.getMinBufferSize(
        RECORD_SAMPLE_RATE,
        AudioFormat.CHANNEL_IN_MONO,
        AudioFormat.ENCODING_PCM_16BIT
      )

      if (minBufferSize == AudioRecord.ERROR || minBufferSize == AudioRecord.ERROR_BAD_VALUE) {
        Log.w(TAG, "Invalid AudioRecord buffer size.")
        return
      }

      audioRecord = AudioRecord(
        MediaRecorder.AudioSource.MIC,
        RECORD_SAMPLE_RATE,
        AudioFormat.CHANNEL_IN_MONO,
        AudioFormat.ENCODING_PCM_16BIT,
        minBufferSize * 2
      )

      if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
        Log.w(TAG, "AudioRecord could not initialize.")
        return
      }

      audioRecord?.startRecording()

      recordingJob = scope.launch(Dispatchers.IO) {
        val buffer = ByteArray(minBufferSize)
        while (isActive && _sessionState.value != LiveSessionState.DISCONNECTED) {
          if (_isMuted.value || _sessionState.value == LiveSessionState.SPEAKING) {
            kotlinx.coroutines.delay(100)
            continue
          }

          val read = audioRecord?.read(buffer, 0, buffer.size) ?: 0
          if (read > 0) {
            // Compute amplitude for UI visualizer
            var sum = 0.0
            val shortsCount = read / 2
            for (i in 0 until shortsCount) {
              val low = buffer[i * 2].toInt() and 0xFF
              val high = buffer[i * 2 + 1].toInt()
              val sample = (high shl 8) or low
              sum += sample * sample
            }
            val rms = if (shortsCount > 0) sqrt(sum / shortsCount) else 0.0
            val amp = (rms / 32768.0).toFloat().coerceIn(0f, 1f)
            _audioAmplitude.value = amp

            // Stream PCM audio chunk over WebSocket if active and voice detected
            if (amp > 0.08f && webSocket != null) {
              try {
                val base64Chunk = Base64.encodeToString(buffer, 0, read, Base64.NO_WRAP)
                val chunkObj = JSONObject()
                val realtimeInput = JSONObject()
                val mediaChunks = JSONArray()
                val mediaChunk = JSONObject()
                mediaChunk.put("mimeType", "audio/pcm;rate=$RECORD_SAMPLE_RATE")
                mediaChunk.put("data", base64Chunk)
                mediaChunks.put(mediaChunk)
                realtimeInput.put("mediaChunks", mediaChunks)
                chunkObj.put("realtimeInput", realtimeInput)

                webSocket?.send(chunkObj.toString())
              } catch (e: Exception) {
                // Ignore transient send failures
              }
            }
          }
        }
      }
    } catch (e: Exception) {
      Log.w(TAG, "Mic recording exception: ${e.message}")
    }
  }

  private fun appendTranscript(isUser: Boolean, text: String) {
    val item = LiveTranscriptItem(isUser = isUser, text = text)
    _transcripts.value = _transcripts.value + item
  }

  fun endSession() {
    cleanUpSession()
    _sessionState.value = LiveSessionState.DISCONNECTED
  }

  private fun cleanUpSession() {
    try {
      recordingJob?.cancel()
      recordingJob = null

      audioRecord?.stop()
      audioRecord?.release()
      audioRecord = null

      audioTrack?.stop()
      audioTrack?.release()
      audioTrack = null

      textToSpeech?.stop()

      webSocket?.close(1000, "User ended live session")
      webSocket = null

      _audioAmplitude.value = 0f
    } catch (e: Exception) {
      Log.w(TAG, "Session cleanup exception: ${e.message}")
    }
  }
}
