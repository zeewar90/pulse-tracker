package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for the habits table.
 */
@Dao
interface HabitDao {
  @Query("SELECT * FROM habits ORDER BY id ASC")
  fun getAllHabits(): Flow<List<Habit>>

  @Query("SELECT * FROM habits WHERE id = :id LIMIT 1")
  suspend fun getHabitById(id: Int): Habit?

  @Query("SELECT COUNT(*) FROM habits")
  suspend fun getHabitCount(): Int

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertHabit(habit: Habit): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(habits: List<Habit>)

  @Update
  suspend fun updateHabit(habit: Habit)

  @Delete
  suspend fun deleteHabit(habit: Habit)

  @Query("DELETE FROM habits WHERE id = :id")
  suspend fun deleteHabitById(id: Int)

  @Query("DELETE FROM habits")
  suspend fun clearAll()
}
