package com.example.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Room Entity representing streak and momentum tracking for a habit.
 */
@Entity(
  tableName = "streaks",
  foreignKeys = [
    ForeignKey(
      entity = Habit::class,
      parentColumns = ["id"],
      childColumns = ["habitId"],
      onDelete = ForeignKey.CASCADE
    )
  ],
  indices = [
    Index(value = ["habitId"], unique = true)
  ]
)
data class Streak(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  @ColumnInfo(name = "habitId")
  val habitId: Int,
  @ColumnInfo(name = "currentStreak")
  val currentStreak: Int = 0,
  @ColumnInfo(name = "bestStreak")
  val bestStreak: Int = 0,
  @ColumnInfo(name = "lastCompletedDate")
  val lastCompletedDate: String? = null, // Date in "yyyy-MM-dd" format
  @ColumnInfo(name = "lastUpdatedTimestamp")
  val lastUpdatedTimestamp: Long = System.currentTimeMillis(),
  @ColumnInfo(name = "startDate")
  val startDate: String? = null
)
