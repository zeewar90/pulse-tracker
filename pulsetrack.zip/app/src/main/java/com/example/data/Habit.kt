package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Room Entity representing a trackable habit in PulseTrack.
 */
@Entity(tableName = "habits")
data class Habit(
  @PrimaryKey(autoGenerate = true)
  val id: Int = 0,
  val name: String,
  val iconName: String = "water",
  val frequency: String = "Daily",
  val dailyGoal: Int = 1,
  val streak: Int = 0,
  val completedToday: Boolean = false,
  // Comma-separated binary indicators for past 7 days (e.g. "1,1,0,1,1,1,1")
  val weeklyHistory: String = "0,0,0,0,0,0,0",
  val bestStreak: Int = 0,
  val createdDate: Long = System.currentTimeMillis()
) {
  fun getWeeklyCompletionList(): List<Boolean> {
    return weeklyHistory.split(",")
      .map { it.trim() == "1" }
      .let {
        if (it.size == 7) it else List(7) { false }
      }
  }

  fun getWeeklyCompletionPercent(): Float {
    val list = getWeeklyCompletionList()
    val completedCount = list.count { it }
    return if (list.isNotEmpty()) (completedCount.toFloat() / list.size.toFloat()) else 0f
  }
}

/**
 * Typealias for backward compatibility with existing codebase.
 */
typealias HabitEntity = Habit
